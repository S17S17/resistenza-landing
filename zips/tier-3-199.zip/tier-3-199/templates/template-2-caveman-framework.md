# Template 2: Caveman Method Framework
## قالب 2: إطار عمل طريقة الرجل الكهفي

**Version 1.0**

---

## The Caveman Method / طريقة الرجل الكهفي

The Caveman Method is about speaking directly to the AI in its "native language" of probability — simple, direct, sequential instructions that reduce the search space for the model.

طريقة الرجل الكهفي تتعلق بالتحدث مباشرة إلى الذكاء الاصطناعي بـ "لغته الأصلية" للاحتمال — تعليمات بسيطة، مباشرة، متسلسلة تقلل مساحة البحث للنموذج.

---

## The Structure / الهيكل

```
[Context]   → الوضع/السياق
[Task]      → المهمة
[Constraints] → القيود
[Format]    → الصيغة
[Example]   → المثال
```

---

## Template / القالب

```markdown
# Caveman Prompt Template

## Context / السياق
[Describe the situation, file, or problem]
[صف الوضع أو المشكلة]

## Task / المهمة
[I need you to + specific action]
[أحبك لـ + فعل محدد]

## Constraints / القيود
[While + specific limitations]
[مع + قيود محددة]

## Format / الصيغة
[Output + exact format specification]
[أرجع + مواصفات الصيغة بالضبط]

## Example / مثال
[Like + concrete example]
[مثل + مثال ملموس]
```

---

## Examples / الأمثلة

### Example 1: Bug Fix / إصلاح خطأ

**Template Applied:**
```
Context: I have a bug in auth.py. The login function throws 
"Cannot read property 'id' of undefined" when users try to login.

Task: Find the bug and fix it.

Constraints: 
- Use only the existing code structure
- Don't change the function signature
- Add proper error handling

Format: Return the fixed function with comments explaining the fix.

Example: Like how error handling is done in the register() function 
in the same file.
```

**النتيجة / Result:**
النموذج سيجد الخطأ بسرعة ويصلحه بوضوح.

### Example 2: New Feature / ميزة جديدة

**Template Applied:**
```
Context: I have a React component called UserProfile.jsx that shows user info.

Task: Add a dark mode toggle to the component.

Constraints:
- Use CSS variables for theming
- Persist preference in localStorage
- Don't break existing functionality

Format: Return the complete updated component file.

Example: Like the existing theme implementation in Button.jsx.
```

### Example 3: Arabic Documentation / توثيق عربي

**Template Applied:**
```
Context: I have a Python function that processes Arabic text.

Task: Write Arabic documentation for this function.

Constraints:
- Write in Modern Standard Arabic (MSA)
- Keep technical terms in English
- Include usage examples

Format: 
- Function description
- Parameters (name, type, description)
- Return value
- Example usage

Example: Like the docstring style in PEP 257 but in Arabic.
```

---

## Why It Works / لماذا يعمل

1. **Direct Commands** = Less ambiguity
   أوامر مباشرة = غموض أقل

2. **Sequential Steps** = Clear logic path
   خطوات متسلسلة = مسار منطقي واضح

3. **Specific Examples** = Pattern anchoring
   أمثلة محددة = تثبيت الأنماط

4. **Explicit Format** = Predictable output
   صيغة صريحة = مخرجات يمكن التنبؤ بها

---

## Token Optimization / تحسين التوكنات

For Arabic, the Caveman Method is especially effective because:

1. Shorter prompts = fewer Arabic tokens
2. Direct commands reduce hallucination
3. Examples are more token-efficient than lengthy explanations

ل للعربية، طريقة الرجل الكهفي فعالة بشكل خاص لأن:

1. أوامر أقصر = توكنات عربية أقل
2. الأوامر المباشرة تقلل الهلوسة
3. الأمثلة أكثر كفاءة في التوكنات من الشروحات الطويلة

---

## Quick Reference Card / بطاقة مرجع سريع

```
╔═══════════════════════════════════════════════════════╗
║          CAVEMAN METHOD QUICK REFERENCE               ║
╠═══════════════════════════════════════════════════════╣
║                                                       ║
║  [Context]     لدي / I have                          ║
║                 المشكلة/الملف/الوضع                    ║
║                                                       ║
║  [Task]        أحتاجك لـ / I need you to              ║
║                 الفعل المحدد                           ║
║                                                       ║
║  [Constraints] مع / While                            ║
║                 القيود المحددة                         ║
║                                                       ║
║  [Format]      أرجع / Output                         ║
║                 الصيغة بالضبط                          ║
║                                                       ║
║  [Example]     مثل / Like                            ║
║                 مثال ملموس                            ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
```

---

*Template 2 Complete*
