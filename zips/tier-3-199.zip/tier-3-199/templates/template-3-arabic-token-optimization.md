# Template 3: Arabic Token Optimization Guide
## قالب 3: دليل تحسين التوكنات للعربية

**Version 1.0**

---

## Arabic Token Optimization / تحسين التوكنات للعربية

This template helps you create prompts that minimize token usage while maintaining Arabic language quality.

هذا القالب يساعدك على إنشاء أوامر تقلل استخدام التوكنات مع الحفاظ على جودة اللغة العربية.

---

## The Token Optimization Checklist / قائمة تحسين التوكنات

```markdown
# Arabic Token Optimization Checklist

## Before Writing Prompt / قبل كتابة الأمر

- [ ] Can I remove diacritics (tashkeel)?
- [ ] Should I use MSA instead of dialect?
- [ ] Can technical terms stay in English?
- [ ] Is there unnecessary repetition?
- [ ] Can examples be shortened?

## Prompt Structure / هيكل الأمر

1. Language instruction (1 time at start)
2. Context (shortest possible)
3. Task (direct command)
4. Constraints (bulleted)
5. Format (exact specification)

## After Response / بعد الرد

- [ ] Is response within token budget?
- [ ] Can I summarize context for next prompt?
- [ ] Should I compress or truncate?
```

---

## Before & After Examples / أمثلة قبل وبعد

### 1. Remove Diacritics / إزالة التشكيل

**Before (more tokens):**
```
عَلَيْكُمْ بِالتَّحَرُّي فِي مَا تَعْمَلُونَ
```

**After (fewer tokens):**
```
عليكم بالتحري فيما تعملون
```

**Savings: ~30-40%**

### 2. Use English for Technical Terms / استخدام الإنجليزية للمصطلحات التقنية

**Before:**
```
استخدم دالة JSON.parse() لتحليل بيانات JSON
```

**After:**
```
Use JSON.parse() to parse JSON data
```

**Savings: ~25%**

### 3. Mix Arabic Context + English Code / خلط السياق العربي + الكود الإنجليزي

**Before:**
```
أنشئ دالة بايثون اسمها process_user_data
تقوم بأخذ قاموس باسم المستخدم وبريده الإلكتروني
وترجع قاموس جديد به الحقول المطلوبة
```

**After:**
```
Create Python function: process_user_data(user_dict)
- Input: {"name": "...", "email": "..."}
- Output: {"name": "...", "email_hash": "..."}
```

**Savings: ~40%**

### 4. Truncate Long Context / قطع السياق الطويل

**Before (all conversation history):**
```
User: كيف أنشئ مشروع جديد؟
Bot: لإنشاء مشروع جديد، استخدم...
User: ما هي الخطوة التالية؟
Bot: الخطوة التالية هي...
[30 more messages]
```

**After (summarized context):**
```
# Context summary:
- User is learning project creation
- Covered: creating new project
- Current: next steps after setup

User: ما هي الخطوة التالية؟
```

**Savings: ~70%**

---

## Token Counter / عداد التوكنات

Use this rough guide for Arabic vs English:

| Content Type | Arabic | English | Ratio |
|--------------|--------|---------|-------|
| Simple word | 1 token | 1 token | 1:1 |
| Common phrase | 1-2 tokens | 1-2 tokens | 1:1 |
| Technical term | 1-2 tokens | 1 token | 2:1 |
| Full sentence | 3-6 tokens | 2-4 tokens | 1.5:1 |
| Paragraph | 20-40 tokens | 15-25 tokens | 1.6:1 |

---

## Arabic Prompt Optimization Template / قالب تحسين الأوامر العربي

```markdown
# Optimized Arabic Prompt

# Language: Arabic explanations, English code
# لا تستخدم التشكيل إلا إذا كان ضرورياً للنطق

## Context (compressed)
[1-2 sentences max]

## Task (direct)
[Verb + specific action]

## Constraints (bulleted)
- [Constraint 1]
- [Constraint 2]

## Format
[Exact output format]

## Example (if needed)
[Short, typical example]
```

---

## Advanced Techniques / تقنيات متقدمة

### 1. Semantic Compression / الضغط الدلالي

Convert verbose Arabic to compressed meaning:

```
Verbose: "أريد منك أن تنظر إلى الكود وتجد فيه أي مشاكل أمنية محتملة"
Compressed: "Review code for security issues"
```

### 2. Abbreviation System / نظام الاختصارات

Use consistent abbreviations:

```
عربي + إنجليزي = AR/EN
مستخدم = U
مكالمة = M
الرسالة = MSG
```

### 3. Template Variables / متغيرات القالب

```markdown
# Instead of writing full context each time:
# بدلاً من كتابة السياق الكامل كل مرة:

# Use:
[U: اسم | رقم: هاتف | لغة: عربي]
```

### 4. Chain Summary Pattern / نمط ملخص السلسلة

For multi-turn conversations:

```markdown
# Session so far:
- Task: [original task]
- Status: [in progress/complete]
- Blockers: [if any]

# Current message:
[new message]

# Action:
[what to do with new message]
```

---

## Quick Reference / مرجع سريع

| Technique | When to Use | Savings |
|-----------|-------------|---------|
| Remove tashkeel | Always | 30-40% |
| English tech terms | Code/technical | 25% |
| MSA over dialect | Always | 10-15% |
| Context compression | Long sessions | 50-70% |
| Example truncation | Non-critical examples | 20-30% |

---

*Template 3 Complete*
