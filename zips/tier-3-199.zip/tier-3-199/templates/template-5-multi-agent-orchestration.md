# Template 5: Multi-Agent Orchestration Template
## قالب 5: قالب تنسيق الوكلاء المتعددين

**Version 1.0**

---

## Multi-Agent Architecture / معمارية الوكلاء المتعددين

This template helps you design and implement multi-agent systems where different AI agents work together to solve complex tasks.

هذا القالب يساعدك على تصميم وتنفيذ أنظمة الوكلاء المتعددين حيث يعمل وكلاء ذكاء اصطناعي مختلفون معاً لحل مهام معقدة.

---

## The Architecture / الهيكل

```markdown
┌─────────────────────────────────────────────────────────┐
│                    USER INPUT                          │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              ORCHESTRATOR AGENT                        │
│                                                         │
│  - Decomposes task                                      │
│  - Assigns to specialized agents                       │
│  - Aggregates results                                   │
│  - Manages context                                      │
└─────────────────────┬───────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        │             │             │
        ▼             ▼             ▼
┌───────────────┐ ┌───────────────┐ ┌───────────────┐
│  SPECIALIST   │ │  SPECIALIST   │ │  SPECIALIST   │
│    AGENT      │ │    AGENT      │ │    AGENT      │
│   (Agent A)   │ │   (Agent B)   │ │   (Agent C)   │
└───────┬───────┘ └───────┬───────┘ └───────┬───────┘
        │                 │                 │
        └─────────────┬─────┴─────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              RESULT AGGREGATOR                          │
│                                                         │
│  - Combines agent outputs                               │
│  - Resolves conflicts                                   │
│  - Formats final response                               │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│                   USER OUTPUT                           │
└─────────────────────────────────────────────────────────┘
```

---

## Template / القالب

### Step 1: Define the Orchestrator / حدد المنسق

```markdown
# Orchestrator Agent Definition

## Role / الدور
You are the Orchestrator. Your job is to coordinate multiple 
specialist agents to complete complex tasks.

## System Prompt / نظام الأوامر
أنت المنسق. عندما تستلم طلباً:

1. تحليل المهمة وتجزئتها
2. حدد الوكلاء المطلوبين
3. وزع المهام
4. اجمع النتائج
5. راجع وأخرج النتيجة النهائية

## Rules / القواعد
- NEVER do the specialist work yourself
- ALWAYS wait for all agents to respond
- Summarize conflicts before final output
- Keep Arabic context throughout
```

### Step 2: Define Specialist Agents / حدد الوكلاء المتخصصين

```markdown
# Specialist Agent A: [Name]

## Role / الدور
[Clear description of this agent's specialty]

## System Prompt / نظام الأوامر
أنت وكيل متخصص في [التخصص].

عند استلام مهمة:
1. اقرأ التعليمات بعناية
2. نفذ المهمة بدقة
3. أرجع النتيجة بالصيغة المحددة

## Output Format / صيغة المخرجات
{
  "agent": "[name]",
  "status": "success/error",
  "result": [specific output],
  "confidence": 0.0-1.0,
  "notes": [any observations]
}
```

### Step 3: Define Communication Flow / حدد تدفق الاتصالات

```markdown
# Communication Protocol / بروتوكول الاتصال

## Message Types / أنواع الرسائل

### 1. Task Assignment / تعيين المهمة
{
  "type": "task",
  "to": "[agent_name]",
  "task_id": "[unique_id]",
  "instructions": "[detailed instructions]",
  "context": [relevant context],
  "priority": "high/medium/low"
}

### 2. Task Response / رد المهمة
{
  "type": "response",
  "from": "[agent_name]",
  "task_id": "[unique_id]",
  "status": "success/error",
  "result": [output],
  "confidence": 0.0-1.0
}

### 3. Aggregation Request / طلب تجميع
{
  "type": "aggregate",
  "results": [array of results],
  "format": "[requested format]"
}
```

### Step 4: Define Error Handling / حدد معالجة الأخطاء

```markdown
# Error Handling / معالجة الأخطاء

## Agent Failure / فشل الوكيل
If an agent fails:
1. Log the failure
2. Retry up to 3 times
3. If still failing, redistribute task
4. Report to orchestrator

## Conflict Resolution / حل التعارضات
If agents disagree:
1. Present both viewpoints
2. Apply voting mechanism
3. Or escalate to human review

## Timeout Handling / معالجة انتهاء المهلة
- Default timeout: 30 seconds
- If exceeded: retry once
- If still timeout: mark as failed and continue
```

---

## Example Implementation / مثال التنفيذ

### Arabic Code Review Multi-Agent / نظام الوكلاء المتعددين لمراجعة الكود العربي

```markdown
# Arabic Code Review System

## Orchestrator / المنسق
أنت منسق مراجعة الكود. تحليل طلب المراجعة، وزع على الوكلاء المتخصصين، اجمع النتائج.

## Agent 1: Security Reviewer / مراجع الأمان
Focus: Security vulnerabilities, injection risks, auth issues
Questions to answer:
- Are there SQL injection risks?
- Is input properly validated?
- Are there exposed secrets?
- Is authentication correct?

## Agent 2: Performance Reviewer / مراجع الأداء
Focus: Performance issues, N+1 queries, missing indexes
Questions to answer:
- Are there performance bottlenecks?
- Is caching used where needed?
- Are queries optimized?

## Agent 3: Arabic/Localization Reviewer / مراجع العربية/التوطين
Focus: RTL support, Arabic text handling, i18n
Questions to answer:
- Is RTL properly implemented?
- Are Arabic strings handled correctly?
- Is localization complete?

## Agent 4: Code Quality Reviewer / مراجع جودة الكود
Focus: Code structure, best practices, maintainability
Questions to answer:
- Is code well-structured?
- Are best practices followed?
- Is documentation adequate?

## Aggregation / التجميع
After all agents respond:
1. Compile all findings
2. Group by severity
3. Sort by priority
4. Format as Arabic report
```

---

## Quick Reference / مرجع سريع

```
╔═══════════════════════════════════════════════════════════╗
║           MULTI-AGENT DESIGN CHECKLIST                     ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  □ Define clear roles for each agent                      ║
║  □ Specify communication protocols                         ║
║  □ Set up error handling for each agent                   ║
║  □ Define result aggregation method                        ║
║  □ Set timeout values                                      ║
║  □ Plan for agent failures                                 ║
║  □ Design conflict resolution                              ║
║  □ Test agent interactions                                 ║
║  □ Monitor agent performance                               ║
║  □ Arabic output from all agents                          ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
```

---

## Common Architectures / الهياكل الشائعة

### 1. Sequential / متسلسل
```
Agent A → Agent B → Agent C → Output
```
Use when: Each step depends on previous

### 2. Parallel / متوازي
```
Agent A ─┐
Agent B ─┼─→ Aggregator → Output
Agent C ─┘
```
Use when: Independent tasks

### 3. Hierarchical / هرمي
```
Orchestrator
    ├── Sub-Orchestrator A
    │     ├── Agent A1
    │     └── Agent A2
    └── Sub-Orchestrator B
          ├── Agent B1
          └── Agent B2
```
Use when: Complex domain separation

### 4. Pipeline / خط أنابيب
```
Input → Stage 1 → Stage 2 → Stage 3 → Output
```
Use when: Strict ordered processing

---

*Template 5 Complete*
