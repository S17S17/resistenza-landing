# Niche Prompts: WhatsApp, n8n, MCP
## أوامر متخصصة: واتساب، n8n، MCP

**Tier 3 — Agency**
Version 1.0 — April 2026

---

##如何使用 / How to Use

These specialized prompts are for advanced users building production WhatsApp agents, n8n workflows, and MCP integrations.

هذه الأوامر المتخصصة للمستخدمين المتقدمين الذين يبنيون وكلاء واتساب للإنتاج وسير عمل n8n وتكاملات MCP.

---

## Section 1: WhatsApp Advanced (1-15)

### 1. Multi-Agent WhatsApp Orchestrator / منسق واتساب متعدد الوكلاء
```
Build a multi-agent WhatsApp orchestrator:

Agents:
- Intent Classifier: classifies customer intent
- Order Agent: handles order creation/tracking
- Support Agent: handles FAQs and complaints
- Escalation Agent: manages human handoffs

Flow:
1. Incoming message → Intent Classifier
2. Classified intent → appropriate agent
3. Agent processes → generates response
4. If needed → Escalation Agent → human handoff

Requirements:
- Session context preservation
- Arabic language support
- Fallback handling
- Analytics logging
```

### 2. WhatsApp RAG Knowledge Base / قاعدة معرفة RAG لوكلاء واتساب
```
Build a RAG system for WhatsApp bot:

Knowledge Sources:
- [product docs]
- [FAQ documents]
- [policy documents]

Vector Store: [Pinecone/Weaviate/Chroma]

Requirements:
- Arabic text chunking
- Semantic search
- Citation of sources
- Confidence thresholds
- Regular updates

Implementation:
1. Index knowledge base
2. Retrieve relevant context
3. Generate response with context
4. Cite sources in response
```

### 3. WhatsApp Payment Flow / سير عمل الدفع عبر واتساب
```
Implement WhatsApp payment flow:

Provider: [Mada/PayTabs/Stripe/etc.]

Flow:
1. Customer selects products
2. Generate payment link
3. Send via WhatsApp
4. Handle payment webhook
5. Confirm payment
6. Send receipt

Requirements:
- Arabic checkout interface
- PCI compliance
- Retry handling
- Refund support
- Payment confirmation
```

### 4. WhatsApp Session Management / إدارة جلسات واتساب
```
Build WhatsApp session management:

Features:
- Session creation (new customer)
- Session continuation (returning)
- Session timeout (after X minutes)
- Session transfer (to human)
- Session analytics

Storage: [Redis/Database]

Requirements:
- Persistent sessions across bot restarts
- Session data encryption
- Memory summarization for long sessions
- Arabic session labels
```

### 5. WhatsApp Broadcast System / نظام البث عبر واتساب
```
Build a WhatsApp broadcast system:

Features:
- Audience segmentation
- Message templates
- Scheduling
- Personalization
- Delivery tracking

Requirements:
- Meta-approved templates
- Rate limiting compliance
- Opt-out handling
- Analytics (delivered/read/responded)
- Arabic message support
```

### 6. WhatsApp Commerce Bot / بوت تجارة واتساب
```
Build a complete WhatsApp commerce bot:

Features:
- Product catalog browsing
- Search with filters
- Cart management
- Order placement
- Payment integration
- Order tracking
- Cancellation/refund

Requirements:
- Arabic product names and descriptions
- Image handling
- Session persistence
- Inventory sync
- Arabic receipts
```

### 7. WhatsApp Appointment Booking / حجز المواعيد عبر واتساب
```
Build WhatsApp appointment booking:

Features:
- Show available slots
- Customer selection
- Confirmation
- Reminders
- Cancellation/rescheduling

Calendar: [Google Calendar/Notion/etc.]

Requirements:
- Arabic date/time format
- Timezone handling
- Buffer time between appointments
- Overbooking prevention
- Arabic SMS reminders
```

### 8. WhatsApp Lead Qualification / تأهيل العملاء المحتملين
```
Build WhatsApp lead qualification bot:

Qualification criteria:
- [criterion 1]
- [criterion 2]
- [criterion 3]

Scoring:
- Hot (score > X)
- Warm (score > Y)
- Cold (score < Y)

Requirements:
- Arabic conversation flow
- CRM integration
- Score tracking
- Automated follow-up
- Arabic lead report
```

### 9. WhatsApp Survey/Feedback / استطلاع/ملاحظات واتساب
```
Build WhatsApp survey system:

Survey: [describe survey]

Features:
- Interactive questions
- Conditional branching
- Arabic text support
- Progress indicator
- Partial response handling

Requirements:
- Meta-compliant
- Anonymous option
- Arabic analytics
- Export results
```

### 10. WhatsApp Two-Way Sync / مزامنة ثنائية الاتجاه لوكلاء واتساب
```
Build WhatsApp two-way sync:

Sync with:
- CRM: [HubSpot/Salesforce/Zoho]
- ERP: [SAP/Oracle/etc.]
- Inventory: [system name]

Features:
- Real-time sync
- Conflict resolution
- Retry queue
- Audit log

Requirements:
- Bidirectional updates
- Error handling
- Arabic field labels
- Monitoring dashboard
```

### 11. WhatsApp AI Voice / واتساب بالذكاء الاصطناعي الصوتي
```
Build WhatsApp voice message processing:

Pipeline:
1. Receive voice message
2. Convert to text (Arabic ASR)
3. Process with AI
4. Generate text response
5. Convert to voice (Arabic TTS)
6. Send as voice reply

Requirements:
- Arabic speech recognition
- Handle different dialects
- Audio quality optimization
- Latency < 30 seconds
```

### 12. WhatsApp Multi-Brand / واتساب متعدد العلامات التجارية
```
Build multi-brand WhatsApp support:

Brands:
- [Brand A]
- [Brand B]

Features:
- Brand identification
- Separate knowledge bases
- Brand-specific responses
- Unified dashboard
- Separate analytics per brand

Requirements:
- Shared infrastructure
- Brand isolation
- Arabic for all brands
- Cross-brand customer view
```

### 13. WhatsApp Verification Flow / سير عمل التحقق عبر واتساب
```
Build WhatsApp verification:

Verification methods:
- OTP via WhatsApp
- Document verification
- Biometric (if supported)

Requirements:
- Arabic instructions
- Retry limits
- Security measures
- Compliance with regulations
- Arabic verification status messages
```

### 14. WhatsApp Proactive Messaging / الرسائل الاستباقية لوكلاء واتساب
```
Build proactive WhatsApp messaging:

Use cases:
- Appointment reminders
- Order status updates
- Payment reminders
- Cart abandonment
- Re-engagement campaigns

Requirements:
- Template approval
- Opt-in check
- Timing optimization
- Arabic templates
- Delivery tracking
```

### 15. WhatsApp Conversation AI / المحادثة الذكية لوكلاء واتساب
```
Build conversational AI for WhatsApp:

Capabilities:
- Contextual understanding
- Multi-turn conversations
- Arabic dialect handling
- Personality consistency
- Emotion detection

Requirements:
- Fine-tuned Arabic model
- Conversation state machine
- Fallback to human
- Learning from interactions
- Arabic personality guidelines
```

---

## Section 2: n8n Workflows (16-30)

### 16. n8n AI Agent Workflow / سير عمل وكيل الذكاء الاصطناعي في n8n
```
Build an AI agent workflow in n8n:

Components:
1. Trigger (Webhook/Schedule)
2. AI Agent node with tools
3. Tool nodes (search, calculate, etc.)
4. Response formatter

Tools:
- Web search
- Database query
- Calculator
- Date/time

Requirements:
- Arabic language support
- Error handling
- Token optimization
- Logging
```

### 17. n8n RAG Pipeline / خط أنابيب RAG في n8n
```
Build RAG pipeline in n8n:

Stages:
1. Document upload (PDF/DOCX)
2. Text extraction
3. Chunking
4. Embedding generation
5. Vector storage
6. Retrieval
7. Generation
8. Response

Requirements:
- Arabic text handling
- PDF/DOCX parsing
- Chunk size optimization
- Arabic embedding model
- Source citation
```

### 18. n8n WhatsApp Integration / دمج واتساب في n8n
```
Build n8n workflow for WhatsApp:

Features:
- Receive WhatsApp messages
- Process with AI
- Send responses
- Handle media
- Session management

Requirements:
- WhatsApp Business API
- Arabic message handling
- Error recovery
- Rate limiting
- Arabic templates
```

### 19. n8n CRM Automation / أتمتة CRM في n8n
```
Build CRM automation in n8n:

Features:
- Lead capture from multiple sources
- Auto-assignment
- Follow-up reminders
- Status updates
- Arabic customer data

Integrations:
- [CRM name]
- [Other tools]

Requirements:
- Arabic field support
- Workflow automation
- Notification system
- Arabic reports
```

### 20. n8n Email Parser / محلل البريد الإلكتروني في n8n
```
Build email parser in n8n:

Features:
- IMAP connection
- Email extraction
- Classification
- Routing
- Response generation

Requirements:
- Arabic email support
- Attachment handling
- Thread detection
- Arabic auto-reply
- Email forwarding rules
```

### 21. n8n Scheduler Agent / وكيل الجدولة في n8n
```
Build AI scheduler agent in n8n:

Features:
- Natural language scheduling
- Calendar integration
- Conflict detection
- Arabic date/time handling
- Reminder management

Requirements:
- Google Calendar / Outlook integration
- Arabic time formats
- Timezone handling
- Buffer time management
- Arabic confirmation messages
```

### 22. n8n Invoice Processing / معالجة الفواتير في n8n
```
Build invoice processing in n8n:

Flow:
1. Receive invoice (email/WhatsApp/upload)
2. Extract data (OCR/API)
3. Validate against system
4. Route for approval
5. Store and notify

Requirements:
- Arabic invoice format
- OCR for Arabic
- Data extraction accuracy
- Approval workflow
- Arabic invoice archive
```

### 23. n8n Social Media Manager / مدير وسائل التواصل الاجتماعي
```
Build social media automation in n8n:

Platforms:
- Twitter/X
- Instagram
- LinkedIn
- Facebook

Features:
- Content scheduling
- Arabic content optimization
- Hashtag suggestions
- Analytics
- Engagement response

Requirements:
- Platform API integration
- Arabic text optimization
- Image handling
- Scheduling
- Arabic analytics
```

### 24. n8n Data Pipeline / خط أنابيب البيانات في n8n
```
Build data pipeline in n8n:

Sources:
- [source 1]
- [source 2]

Transformations:
- Clean data
- Normalize fields
- Arabic text processing
- Aggregate metrics

Destinations:
- [warehouse]
- [analytics]

Requirements:
- Data validation
- Error handling
- Monitoring
- Arabic field names
```

### 25. n8n Meeting Analyzer / محلل الاجتماعات
```
Build meeting analysis in n8n:

Features:
- Transcript capture
- AI summarization
- Action item extraction
- Arabic transcription

Requirements:
- Meeting platform integration
- Arabic speech-to-text
- Key point detection
- Arabic summary format
- Follow-up task creation
```

### 26. n8n Customer Feedback Loop / حلقة ملاحظات العملاء
```
Build customer feedback loop in n8n:

Flow:
1. Collect feedback (survey/WhatsApp/email)
2. Analyze sentiment
3. Route by severity
4. Trigger actions
5. Close the loop

Requirements:
- Arabic text analysis
- Sentiment scoring
- Arabic response templates
- CRM update
- Arabic reporting
```

### 27. n8n Document Generator / مولد المستندات
```
Build document generation in n8n:

Documents:
- Invoices
- Contracts
- Reports
- Arabic letters

Features:
- Template management
- Arabic text support
- PDF generation
- E-signature integration

Requirements:
- Arabic template design
- RTL formatting
- Dynamic fields
- Arabic number formatting
```

### 28. n8n Alerting System / نظام التنبيهات
```
Build AI-powered alerting in n8n:

Features:
- Monitor systems
- Analyze patterns
- Detect anomalies
- Route alerts
- Arabic notifications

Requirements:
- Multi-channel alerts
- Arabic alert messages
- Severity classification
- Escalation rules
- Alert history
```

### 29. n8n Onboarding Flow / سير عمل إعداد العملاء
```
Build customer onboarding in n8n:

Steps:
1. Welcome message
2. Collect information
3. Setup account
4. Send resources
5. Schedule intro call
6. Follow-up sequence

Requirements:
- Arabic welcome messages
- Multi-channel sequence
- Progress tracking
- Arabic instructions
- Completion triggers
```

### 30. n8n Multi-Agent Workflow / سير عمل متعدد الوكلاء
```
Build multi-agent workflow in n8n:

Agents:
- Classifier Agent
- Researcher Agent  
- Writer Agent
- Reviewer Agent

Orchestration:
- Sequential routing
- Parallel execution
- Conditional branching
- Result aggregation

Requirements:
- Agent definitions
- Tool sharing
- Error handling
- Arabic outputs
```

---

## Section 3: MCP Integration (31-45)

### 31. MCP Database Agent / وكيل قاعدة بيانات MCP
```
Build MCP database agent:

Capabilities:
- Natural language queries
- Schema understanding
- Query generation
- Result explanation
- Arabic output

Database: [PostgreSQL/MySQL/etc.]

Requirements:
- Schema documentation
- Query validation
- Arabic column descriptions
- Result formatting
- Execution safety
```

### 32. MCP File System Agent / وكيل نظام الملفات MCP
```
Build MCP file system agent:

Capabilities:
- Search files by content
- Analyze code structure
- Read/write operations
- Batch operations
- Arabic comments in files

Requirements:
- Permission management
- Path safety
- Operation logging
- Arabic documentation
- Backup before write
```

### 33. MCP Git Agent / وكيل Git MCP
```
Build MCP Git agent:

Capabilities:
- Repository operations
- Code review
- Commit message generation
- Branch management
- Arabic commit messages

Requirements:
- Auth management
- Operation validation
- Arabic output
- Git best practices
- Audit trail
```

### 34. MCP API Agent / وكيل API MCP
```
Build MCP API agent:

Capabilities:
- API discovery
- Request building
- Response parsing
- Arabic documentation
- Integration testing

APIs: [REST/GraphQL/etc.]

Requirements:
- Auth handling
- Request validation
- Error interpretation
- Arabic summaries
```

### 35. MCP Cloud Agent / وكيل السحابة MCP
```
Build MCP cloud agent:

Capabilities:
- Resource management
- Cost optimization
- Security scanning
- Arabic reports
- Compliance checking

Provider: [AWS/GCP/Azure]

Requirements:
- Credential management
- Region awareness
- Arabic cost reports
- Alert configuration
- Resource tagging
```

### 36. MCP Browser Agent / وكيل المتصفح MCP
```
Build MCP browser agent:

Capabilities:
- Web scraping
- Form filling
- Screenshots
- Arabic text extraction
- Navigation automation

Requirements:
- Headless browser
- Proxy rotation
- Arabic content handling
- Rate limiting
- Error recovery
```

### 37. MCP Container Agent / وكيل الحاويات MCP
```
Build MCP container agent:

Capabilities:
- Container management
- Log analysis
- Resource monitoring
- Health checks
- Arabic alerts

Platform: [Docker/Kubernetes]

Requirements:
- Container orchestration
- Arabic logs summary
- Performance monitoring
- Auto-recovery
```

### 38. MCP Slack Agent / وكيل Slack MCP
```
Build MCP Slack agent:

Capabilities:
- Channel management
- Message posting
- Thread replies
- Arabic messages
- Notification routing

Requirements:
- OAuth management
- Workspace awareness
- Arabic formatting
- Emoji handling
- Arabic thread context
```

### 39. MCP Notion Agent / وكيل Notion MCP
```
Build MCP Notion agent:

Capabilities:
- Page creation
- Database queries
- Content updates
- Arabic content support
- Template filling

Requirements:
- Integration token
- Database mapping
- Arabic property names
- Rich text handling
- Arabic search
```

### 40. MCP Linear Agent / وكيل Linear MCP
```
Build MCP Linear agent:

Capabilities:
- Issue creation
- Workflow automation
- Arabic descriptions
- Status updates
- Sprint management

Requirements:
- API key management
- Team workspace
- Arabic labels
- Workflow rules
- Arabic notifications
```

### 41. MCP Figma Agent / وكيل Figma MCP
```
Build MCP Figma agent:

Capabilities:
- Design review
- Component extraction
- Spec generation
- Arabic annotations
- Asset export

Requirements:
- Figma API access
- Design file mapping
- Arabic text handling
- Export optimization
- Version tracking
```

### 42. MCP Analytics Agent / وكيل التحليلات MCP
```
Build MCP analytics agent:

Capabilities:
- Metric queries
- Report generation
- Arabic visualizations
- Anomaly detection
- Insight summaries

Platform: [GA4/Mixpanel/PostHog/etc.]

Requirements:
- API credentials
- Arabic chart labels
- Date range handling
- Segmentation
- Arabic narratives
```

### 43. MCP Sentry Agent / وكيل Sentry MCP
```
Build MCP Sentry agent:

Capabilities:
- Error monitoring
- Stack trace analysis
- Arabic error messages
- Issue management
- Performance analysis

Requirements:
- Project mapping
- Arabic error context
- Alert configuration
- Resolution workflow
- Arabic summaries
```

### 44. MCP Vercel Agent / وكيل Vercel MCP
```
Build MCP Vercel agent:

Capabilities:
- Deployment management
- Environment config
- Arabic logs
- Domain management
- Performance metrics

Requirements:
- Team access
- Project mapping
- Arabic deployment notes
- Rollback capability
- Arabic analytics
```

### 45. MCP Composite Agent / وكيل مركب MCP
```
Build MCP composite agent:

Architecture:
- Orchestrator agent
- Multiple MCP tool agents
- Result aggregator
- Arabic output formatter

Requirements:
- Tool coordination
- Error handling
- Arabic context preservation
- Performance optimization
- Result validation
```

---

## Section 4: Templates (46-50)

### 46. WhatsApp Agent Starter Template / قالب بدء وكيل واتساب
```
# WhatsApp Agent Starter Template

## Identity
Name: [bot name]
Role: [support/sales/general]
Personality: [friendly/professional/casual]
Language: Arabic (primary)

## Capabilities
- [capability 1]
- [capability 2]

## Limitations
- Cannot process payments directly
- Cannot access account balances
- Transfers to human for [list]

## Conversation Flow
1. Greeting: [Arabic greeting]
2. Intent detection: [how]
3. Processing: [flow]
4. Closing: [Arabic closing]

## Error Handling
- Unclear input: [Arabic message]
- Out of scope: [Arabic message]
- System error: [Arabic message]
```

### 47. n8n Workflow Template / قالب سير عمل n8n
```
# n8n Workflow Template

## Purpose
[Description]

## Trigger
Type: [Webhook/Schedule/Manual]
Config: [details]

## Nodes
1. [Node name]: [purpose]
2. [Node name]: [purpose]

## Connections
[Node1] → [Node2] → [Node3]

## Error Handling
- On error: [action]
- Retry: [times]
- Alert: [channel]

## Arabic Support
- [specific Arabic handling]
```

### 48. MCP Agent Template / قالب وكيل MCP
```
# MCP Agent Template

## Tools
- [tool 1]: description
- [tool 2]: description

## Instructions
You are an agent that [core purpose].
Always:
- [rule 1]
- [rule 2]

Never:
- [prohibition 1]
- [prohibition 2]

## Output Format
[specified format with Arabic]

## Examples
Input: [example]
Output: [example]
```

### 49. Prompt Chain Template / قالب سلسلة الأوامر
```
# Prompt Chain Template

## Chain Overview
[Purpose and flow description]

## Link 1: [Name]
Input: [what comes in]
Prompt: [instruction]
Output: [what comes out]

## Link 2: [Name]
Input: [from Link 1]
Prompt: [instruction]
Output: [what comes out]

## Link 3: [Name]
Input: [from Link 2]
Prompt: [instruction]
Output: [final output]

## Error Handling
- If [condition]: [action]
- If [condition]: [action]
```

### 50. Multi-Agent System Template / قالب نظام متعدد الوكلاء
```
# Multi-Agent System Template

## System Overview
[Description]

## Agent 1: [Name]
Role: [role description]
System Prompt: [detailed prompt]
Tools: [list]
Output: [what it produces]

## Agent 2: [Name]
Role: [role description]
System Prompt: [detailed prompt]
Tools: [list]
Output: [what it produces]

## Orchestrator
Role: Coordinates all agents
System Prompt: [coordination prompt]
Routing: [logic]

## Communication
- [Agent1] → [Orchestrator]
- [Orchestrator] → [Agent2]
- [Agent2] → [Orchestrator]
- [Orchestrator] → [User]

## Arabic Requirements
- [specific Arabic handling]
```

---

*50 Niche Prompts for WhatsApp, n8n, MCP — Tier 3 Agency*
