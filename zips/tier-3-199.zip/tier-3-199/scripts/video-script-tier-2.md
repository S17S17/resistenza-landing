# Video Script: Tier 2 Pro ($79)
## سيناريو الفيديو: المستوى الثاني - الاحترافي ($79)

**Version 1.0**
**Duration: 5-7 minutes**

---

## Scene 1: Hook (0:00-0:45)

**[On camera - professional tone]**

"إذا كنت تستخدم Claude Code، أو GPT، أو Gemini، أو حتى نماذج محلية مثل Gemma..."

"...وتريد نتائج أفضل بنسبة 10x مع أوامر أقل..."

"...هذه الوحدة لك."

"أنا سيمى، وبنيت أكثر من 50 بوت واتساب ذكي في آخر 3 سنوات."

"اليوم، سأعلمك كل تقنياتتي."

---

## Scene 2: The Problem (0:45-1:30)

**[Screen share - bad prompt example]**

"انظر لهذا الأمر..."

"طويل، غير واضح، نتائج غير متوقعة..."

**[Shows result]**

"هذا ما يحصل معظم الوقت."

"لكن مع technique صحيحة..."

**[Shows optimized prompt]**

"...نفس النتيجة في نصف التوكنات."

---

## Scene 3: Course Overview (1:30-3:00)

**[Animated slides]**

"ماذا ستتعلم في الوحدة الاحترافية:"

**الوحدة 1: الأساسيات**
"- كيف تعمل نماذج اللغة"
"- طريقة الرجل الكهفي"
"- تحسين التوكنات للعربية"

**الوحدة 2: وكلاء البرمجة**
"- أوامر Claude Code المتقدمة"
"- تكامل n8n و MCP"
"- النماذج المحلية"

**الوحدة 3: وكلاء واتساب**
"- بناء بوتات واتساب"
"- إدارة الذاكرة والجلسات"
"- RAG للواتساب"

**الوحدة 4: أنظمة الإنتاج**
"- سلاسل الأوامر"
"- تنسيق الوكلاء المتعددين"
"- المراقبة والتقييم"

---

## Scene 4: Deep Demo (3:00-5:00)

**[Full screen recording - multiple examples]**

"دعني أريك أمثلة حقيقية..."

**Demo 1: Arabic WhatsApp Bot (Arabic voiceover)**
"هذا بوت واتساب عربي كامل... [shows prompt + result]"

**Demo 2: Code Review (Arabic + English)**
"مراجعة كود شاملة... [shows prompt + output]"

**Demo 3: Prompt Chain (Arabic explanation)**
"سلسلة أوامر لمعالجة معقدة... [shows workflow]"

---

## Scene 5: Exclusive Content (5:00-6:00)

**[Animated content reveal]**

"هذه الوحدة تتضمن:"

✅ 50 أمراً شاملاً (ليست 20!)
✅ إطار عمل طريقة الرجل الكهفي
✅ 5 قوالب جاهزة للاستخدام
✅ دليل تحسين التوكنات للعربية
✅ تحديثات مدى الحياة
✅ 30 يوم دعم

"حزمة متكاملة من الألف إلى الياء."

---

## Scene 6: Tier Comparison (6:00-6:30)

**[Side-by-side comparison]**

"المبتدئ = $29، 20 أمر فقط"

"الاحترافي = $79، كل شيء +:"
"- 4 وحدات كاملة"
"- 50 أمر"
"- قوالب متعددة"
"- تحديثات"

"$50 إضافية = 10x المزيد من القيمة"

---

## Scene 7: Call to Action (6:30-7:00)

**[On camera - confident]**

"احصل على الوحدة الاحترافية الآن:"
"[ Gumroad Link ]"

"ستجد الرابط في وصف الفيديو."

"أستخدم هذه الأوامر يومياً في مشروعي الخاص."
"الآن، حان دورك."

---

## Production Notes / ملاحظات الإنتاج

### Recording
- Camera: Face cam required (establish authority)
- Screen: Multiple demos, 1080p
- Length: 5-7 minutes

### Tone
- Professional but approachable
- Confident, not arrogant
- Arabic with occasional English for technical terms

### Editing
- Smooth transitions between scenes
- Arabic subtitles for key points
- Show timestamps for each section
- End card with upgrade option

### Equipment
- Quality microphone (Blue Yeti or similar)
- Good lighting (softbox or ring light)
- Second monitor for reference

### Thumbnail
- Arabic: "50 أمراً تغيّر حياتك المهنية"
- Image: Split screen - face + code
- Expression: Accomplished/professional

---

*Video Script Tier 2 Complete*
