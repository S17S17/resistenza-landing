# Video Script: Tier 3 Agency ($199)
## سيناريو الفيديو: المستوى الثالث - الوكالة ($199)

**Version 1.0**
**Duration: 8-10 minutes**

---

## Scene 1: Hook (0:00-1:00)

**[Cinematic opener - laptop + phone on desk]**

"كيف تبني وكالة AI بـ $2000/month..."

"...باستخدام نفس الأدوات التي ستتعلمها اليوم."

"اسمي سيمى. أعمل في مجال وكلاء الذكاء الاصطناعي منذ 3 سنوات."

"اليوم، سأنهار معك كل شيء: من الأوامر إلى الاستشارات الحية."

---

## Scene 2: The Opportunity (1:00-2:00)

**[On camera - talking head with B-roll]**

"السوق العربي في مجال AI agents..."
"...فارغ تماماً."

"لا توجد دورات، لا توجد شهادات، لا يوجد منافسون."

"فقط أنت، ومهاراتك، والطلب المتزايد."

"كل شركة صغيرة تريد بوت واتساب."
"كل مطور يريد يعمل مع AI."
"كلAgency تريد توليد محتوى faster."

"هذا هو وقتك."

---

## Scene 3: What Makes Tier 3 Different (2:00-4:00)

**[Screen share - actual deliverables]**

"ما الذي تحصل عليه بـ $199..."

**1. كل شيء من المستوى الاحترافي**
"50+ أمر، 4 وحدات، قوالب..."

**2. أوامر متخصصة**
"- بوتات واتساب للمتاجر"
"- سير عمل n8n"
"- تكامل MCP"
"- والمزيد..."

**3. استشارات حية**
"3 مكالمات معي شخصياً..."
"للمراجعة، للتدريب، للاستراتيجية."

**4. حقوق white-label**
"بعت الوكلاء لأشخاص آخرين باسمنا؟"
"لا. بعتهم باسمك."

---

## Scene 4: Live Demo - WhatsApp Agent (4:00-6:00)

**[Full demo - building a real bot]**

**[Arabic voiceover with screen recording]**

"دعني أبني بوت واتساب كامل..."
"...من الصفر إلى الإنتاج..."
"...أمامك."

**[Steps shown]**
1. "هذا الأمر... [write prompt]"
2. "هذا سير العمل... [show n8n]"
3. "هذا التكامل... [show MCP]"
4. "ونتيجة؟... [show working bot]"

"6 دقائق من الصفر إلى بوت يعمل."

---

## Scene 5: Case Study (6:00-7:30)

**[On camera with slides]**

"案例 دراسة:"

**[Show actual results]**
"عميل: متجر إلكتروني عربي"
"المشكلة: دعم عملاء يدوي 24/7"
"الحل: بوت واتساب ذكي"

"النتيجة:"
"- 70% من الاستفسارات تلقائية"
"- وقت الاستجابة: من 2 ساعة إلى 3 ثوانٍ"
"- رضا العملاء: +40%"

"التكلفة: $199 للتدريب + $50/month للتشغيل"
"العائد: لا يقدر بثمن."

---

## Scene 6: What's Included (7:30-8:30)

**[Animated checklist]**

"حزمة الوكالة الكاملة:"

✅ كل شيء من Tier 2 ($79 value)
✅ 50+ أمر إضافي متخصص
✅ 3 استشارات حية (30 دقيقة كل واحدة)
✅ حقوق White-label
✅ دعم أولوي مدى الحياة
✅ الوصول لـ private community

"إجمالي القيمة: أكثر من $1000"
"سعر الوكالة: $199"

---

## Scene 7: Investment Breakdown (8:30-9:00)

**[On camera - value framing]**

"دعني أريك الرياضيات..."

"1 بوت واتساب للعميل = $300-500/month"
"1 workflow n8n = $200-500/project"
"1 استشارة = $100-200/hour"

"بمجرد أن تتعلم هذه المهارات..."
"...كل عميل جديد = $200-500+"

"الاستثمار الأول: $199"
"العميل الأول: $300+"
"الأرباح: ابدأ من العميل الثاني."

---

## Scene 8: Call to Action (9:00-9:30)

**[On camera - direct and confident]**

"احصل على حزمة الوكالة:"
"[ Gumroad Link ]"

"سجل الآن. سنرسل لك كل شيء خلال 24 ساعة."

"ثم حجز أول استشارة."

"أراك هناك."

---

## Scene 9: Outro (9:30-10:00)

**[Slower pace, professional]**

"تذكر:"
"المهارات التي تتعلمها اليوم..."
"...ستحدد مستقبلك في مجال AI."

"لا تنتظر الفرصة."
"أنشئها."

"[اسم القناة/الباند]"

---

## Production Notes / ملاحظات الإنتاج

### Recording
- Camera: High quality face cam (establish authority)
- Screen: Professional demos, multiple screens
- Length: 8-10 minutes

### Tone
- Confident, professional
- Arabic primary, English for technical
-_URI framework: "I'm the expert, follow me"

### Editing
- Cinematic feel
- Music bed throughout
- Smooth animations
- Professional lower thirds

### Equipment
- Cinema camera or high-end DSLR
- Professional lighting (3-point setup)
- Lavalier microphone
- Teleprompter for key sections

### Thumbnail
- Arabic: "肘بني Agency AI من الصفر"
- Image: Professional headshot + laptop
- Expression: Confident, leading
- Tag: "$199 Agency Package"

### B-Roll Shots
- Workspace establishing shots
- Coffee cup, notebook
- Phone with WhatsApp
- Code editor with Arabic comments

---

*Video Script Tier 3 Complete*
