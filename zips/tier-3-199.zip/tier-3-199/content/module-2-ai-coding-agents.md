# Module 2: AI Coding Agents
## الوحدة الثانية: وكلاء البرمجة الذكية

**Arabic Edition**
Version 1.0 — April 2026

---

## Table of Contents / جدول المحتويات

1. Claude Code Prompts for Arabic Developers / أوامر Claude Code لمطوري البرمجيات العرب
2. n8n + AI Agent Prompts / أوامر n8n + الوكيل الذكي
3. MCP Integration Prompts / أوامر تكامل MCP
4. Local AI Prompts (Gemma, LM Studio, Ollama) / أوامر الذكاء المحلي
5. Prompt Chaining Patterns / أنماط串联 الأوامر

---

## Chapter 1: Claude Code Prompts for Arabic Developers

### English

Claude Code is Anthropic's CLI tool for AI-assisted coding. It uses Claude to understand your codebase, write code, run commands, and iterate.

**Key Claude Code Commands:**

```bash
# Start a new session
claude

# Start with a specific task
claude "Fix the login bug in auth.py"

# Resume an interrupted session
claude --resume

# Specify a model
CLAUDE_MODEL=claude-opus-4o claude
```

**Effective Claude Code Prompts for Arabic Developers:**

**1. Project Initialization Prompt**
```
Initialize a new Node.js project for an Arabic WhatsApp bot.
Requirements:
- TypeScript with strict mode
- Express.js for API
- PostgreSQL with Prisma ORM
- WhatsApp Web JS library
- Arabic language support (RTL)
- Include .env.example with all required variables

Start by creating SPEC.md, then set up the project structure.
```

**2. Feature Development Prompt**
```
In the src/auth/ folder, implement JWT-based authentication:
- Generate JWT tokens on successful login
- Add refresh token rotation
- Create middleware for protected routes
- Store tokens in HTTPOnly cookies
- Handle token expiration gracefully

Use TypeScript with proper types. Include unit tests for the auth functions.
```

**3. Bug Investigation Prompt**
```
I'm getting this error when users try to upload files larger than 5MB:

Error: ENOENT: no such file or directory, open '/tmp/uploads/2026-04-06'

1. Find the root cause
2. Show me the exact code causing the issue
3. Fix it with proper error handling
4. Add file size validation before upload
```

**4. Code Review Prompt**
```
Review the src/api/ folder for security vulnerabilities:
- Check for SQL injection risks
- Verify input validation everywhere
- Look for exposed secrets or API keys
- Check rate limiting implementation
- Verify CORS configuration

For each issue found: severity, location, and fix recommendation.
```

**5. Refactoring Prompt**
```
Refactor src/utils/logger.ts to:
- Support multiple log levels (debug, info, warn, error)
- Add structured logging with JSON output
- Include request ID tracking
- Make it thread-safe for concurrent requests
- Add unit tests with mocked console

Keep the same API so existing code doesn't break.
```

### العربية

Claude Code هو أداة CLI من Anthropic للترميز بمساعدة الذكاء الاصطناعي. يستخدم Claude لفهم قاعدة الكود الخاصة بك، كتابة الكود، تنفيذ الأوامر، والتكرار.

**أوامر Claude Code الرئيسية:**

```bash
# بدء جلسة جديدة
claude

# البدء بمهمة محددة
claude "Fix the login bug in auth.py"

# استئناف جلسة مقاطعة
claude --resume

# تحديد النموذج
CLAUDE_MODEL=claude-opus-4o claude
```

**أوامر Claude Code الفعالة لمطوري البرمجيات العرب:**

**1. أمر تهيئة المشروع**
```
قم بتهيئة مشروع Node.js جديد لبوت واتساب عربي.
المتطلبات:
- TypeScript مع الوضع الصارم
- Express.js للـ API
- PostgreSQL مع Prisma ORM
- مكتبة WhatsApp Web JS
- دعم اللغة العربية (RTL)
- أضف .env.example مع جميع المتغيرات المطلوبة

ابدأ بإنشاء SPEC.md، ثم قم بإعداد هيكل المشروع.
```

**2. أمر تطوير الميزات**
```
في مجلد src/auth/،نفذ المصادقة المبنية على JWT:
- إنشاء رموز JWT عند تسجيل الدخول الناجح
- إضافة تدوير رمز التحديث
- إنشاء وسيط للمسارات المحمية
- تخزين الرموز في ملفات تعريف الارتباط HTTPOnly
- التعامل مع انتهاء صلاحية الرمز بشكل سلس

استخدم TypeScript مع الأنواع المناسبة. أضف اختبارات وحدة لدوال المصادقة.
```

**3. أمر التحقيق في الأخطاء**
```
أحصل على هذا الخطأ عندما يحاول المستخدمون رفع ملفات أكبر من 5 ميجابايت:

Error: ENOENT: no such file or directory, open '/tmp/uploads/2026-04-06'

1. ابحث عن السبب الجذري
2. أرني الكود الدقيق الذي يسبب المشكلة
3. أصلحه مع معالجة الأخطاء المناسبة
4. أضف التحقق من حجم الملف قبل الرفع
```

---

## Chapter 2: n8n + AI Agent Prompts

### English

n8n is a workflow automation platform that can connect AI agents to various services. Here are key prompts for n8n AI workflows:

**1. n8n AI Sub-Node Prompt**
```
You are an n8n AI sub-node that processes customer inquiries.

Input: Customer message in Arabic or English
Task: 
1. Detect language (Arabic/English)
2. Classify intent: [support, sales, feedback, other]
3. Generate appropriate response
4. Set confidence score (0-1)

Output format:
{
  "language": "ar|en",
  "intent": "support|sales|feedback|other",
  "response": "generated response text",
  "confidence": 0.0-1.0,
  "escalate": true|false
}

Never invent information. If unsure, set escalate: true.
```

**2. n8n RAG Workflow Prompt**
```
You are part of an n8n RAG (Retrieval Augmented Generation) workflow.

Context from knowledge base:
{{$json.retrieved_context}}

User query: {{$json.user_query}}

Task: Answer the user query using ONLY the provided context.
If the context doesn't contain the answer, say:
"لا أستطيع الإجابة على هذا السؤال بناءً على المعلومات المتاحة" (I cannot answer this question based on available information)

Format your answer in Arabic if the query is Arabic, English if English.
```

**3. n8n WhatsApp Integration Prompt**
```
Process this incoming WhatsApp message for an Arabic customer service bot:

Message: {{$json.message}}
Phone: {{$json.phone}}
Name: {{$json.name}}
Time: {{$json.timestamp}}

Task:
1. Classify the message type: [greeting, question, complaint, order, other]
2. Check if this is a returning customer (query the database)
3. Generate appropriate response in the customer's language
4. Determine if human escalation is needed

Respond with JSON for n8n to process the next step.
```

### العربية

n8n هي منصة أتمتة سير العمل يمكنها ربط الوكلاء الذكيين بخدمات مختلفة. إليك أوامر رئيسية لسير عمل n8n AI:

**1. أمر n8n AI Sub-Node**
```
أنت عقدة فرعية AI في n8n تعالج استفسارات العملاء.

المدخلات: رسالة العميل بالعربية أو الإنجليزية
المهمة:
1. كشف اللغة (عربية/إنجليزية)
2. تصنيف النية: [دعم، مبيعات، ملاحظات، أخرى]
3. إنشاء رد مناسب
4. تحديد درجة الثقة (0-1)

صيغة المخرجات:
{
  "language": "ar|en",
  "intent": "support|sales|feedback|other",
  "response": "نص الرد المُنشأ",
  "confidence": 0.0-1.0,
  "escalate": true|false
}

لا تختلق معلومات. إذا لم تكن متأكداً، ضع escalate: true.
```

**2. أمر n8n RAG Workflow**
```
أنت جزء من سير عمل n8n RAG (الاسترجاع المعزز بالتوليد).

السياق من قاعدة المعرفة:
{{$json.retrieved_context}}

استفسار المستخدم: {{$json.user_query}}

المهمة: أجب على استفسار المستخدم باستخدام السياق المتاح فقط.
إذا لم يحتوي السياق على الإجابة، قل:
"لا أستطيع الإجابة على هذا السؤال بناءً على المعلومات المتاحة"

صيغة إجابتك بالعربية إذا كان الاستفسار بالعربية، بالإنجليزية إذا كان بالإنجليزية.
```

---

## Chapter 3: MCP Integration Prompts

### English

MCP (Model Context Protocol) allows AI agents to connect to external tools and data sources. Here are prompts for MCP integration:

**1. MCP Database Query Prompt**
```
You have access to a PostgreSQL database via MCP.

Connected database: production_ecommerce
Available tables:
- users (id, name, email, phone, created_at)
- orders (id, user_id, total, status, created_at)
- products (id, name, price, stock)
- order_items (id, order_id, product_id, quantity)

Task: Find the top 5 customers by total order value in the last 30 days.
Include their name, email, total orders, and total value.

Format as a markdown table.
```

**2. MCP File System Prompt**
```
You have MCP access to the file system at /app/project.

Task:
1. First read SPEC.md to understand the project
2. Find all TypeScript files in src/
3. Identify any files that don't have .spec.ts or .test.ts companions
4. List those files with their paths
5. For each missing test file, suggest what tests should be written

Output a report in Arabic.
```

**3. MCP API Integration Prompt**
```
You have MCP access to make HTTP requests.

Base URL: https://api.example.com/v1
Auth: Bearer token (use MCP secret: api_token)

Task: 
1. GET /users?role=admin to find admin users
2. For each admin, GET /users/{id}/activity to get recent activity
3. Format a summary report of admin activity

Handle errors gracefully. If any request fails, continue with the others and note the failure.
```

### العربية

MCP (بروتوكول سياق النموذج) يسمح للوكلاء الذكيين بالاتصال بأدوات ومصادر بيانات خارجية. إليك أوامر لتكامل MCP:

**1. أمر استعلام قاعدة بيانات MCP**
```
لديك حق الوصول إلى قاعدة بيانات PostgreSQL عبر MCP.

قاعدة البيانات المتصلة: production_ecommerce
الجداول المتاحة:
- users (id, name, email, phone, created_at)
- orders (id, user_id, total, status, created_at)
- products (id, name, price, stock)
- order_items (id, order_id, product_id, quantity)

المهمة: اعثر على أفضل 5 عملاء حسب قيمة الطلبات الإجمالية في آخر 30 يوماً.
شمل اسمهم، بريدهم الإلكتروني، عدد الطلبات، والقيمة الإجمالية.

صيغ كجدول markdown.
```

**2. أمر نظام ملفات MCP**
```
لديك حق الوصول MCP لنظام الملفات في /app/project.

المهمة:
1. اقرأ SPEC.md أولاً لفهم المشروع
2. اعثر على جميع ملفات TypeScript في src/
3. حدد أي ملفات ليس لها ملفات .spec.ts أو .test.ts مرافقة
4. ضع قائمة بتلك الملفات مع مساراتها
5. لكل ملف اختبار مفقود، اقترح ما يجب اختباره

أخرج تقريراً بالعربية.
```

---

## Chapter 4: Local AI Prompts (Gemma, LM Studio, Ollama)

### English

Running AI locally means you control your data and don't pay per-token costs. Here's how to optimize prompts for local models:

**1. Gemma 3 Prompt (4B/7B optimized)**
```
You are a helpful Arabic-speaking coding assistant.
Keep responses concise and practical.
For code: always provide working examples.
Language: Respond in Arabic for general topics.
For technical terms: keep in English.

Task: [describe task]
```

**2. LM Studio Prompt**
```
System: You are an Arabic developer assistant.
- Arabic explanations for concepts
- English for code and technical terms
- Concise, practical advice
- Always show working code examples

User: [task description]
```

**3. Ollama Prompt (Mistral-based)**
```
[INST]
You are a bilingual Arabic/English coding assistant.
Use Arabic for explanations, English for code.
Keep responses focused and actionable.
Include practical examples.
[/INST]

[task]
```

**4. Local Code Review Prompt**
```
Review this Arabic web app code for common issues:

Language: TypeScript
Framework: Next.js
Focus areas:
- RTL implementation
- Arabic font rendering
- Input validation for Arabic text
- Date/time handling for Arabic locale

Code:
[insert code]

Provide a structured report with:
1. Issues found (severity: high/medium/low)
2. Location
3. Recommended fix
```

### العربية

تشغيل الذكاء الاصطناعي محلياً يعني أنك تتحكم في بياناتك ولا تدفع تكاليف لكل توكن. إليك كيفية تحسين الأوامر للنماذج المحلية:

**1. أمر Gemma 3 (محسن لـ 4B/7B)**
```
أنت مساعد ترميز ناطق بالعربية.
حافظ على ردود مختصرة وعملية.
للكود: قدم دائماً أمثلة تعمل.
اللغة: رد بالعربية للمواضيع العامة.
للمصطلحات التقنية: احتفظ بالإنجليزية.

المهمة: [وصف المهمة]
```

**2. أمر LM Studio**
```
النظام: أنت مساعد مطور عربي.
- شروحات عربية للمفاهيم
- الإنجليزية للكود والمصطلحات التقنية
- نصائح مختصرة وعملية
- قدم دائماً أمثلة كود تعمل

المستخدم: [وصف المهمة]
```

---

## Chapter 5: Prompt Chaining Patterns

### English

Prompt chaining connects multiple LLM calls to handle complex workflows. Here are key patterns:

**1. Sequential Chain Pattern**
```
Chain: Analyze → Plan → Execute → Review

Step 1 (Analyze):
Task: Analyze this codebase and identify the main components.
Output: List of components with descriptions.

Step 2 (Plan):
Based on Step 1 output, create an implementation plan.
Output: Ordered list of changes needed.

Step 3 (Execute):
Based on Step 2 plan, implement the changes.
Output: Updated code files.

Step 4 (Review):
Review Step 3 output for bugs and improvements.
Output: Final code + list of any remaining issues.
```

**2. Parallel Chain Pattern**
```
Task: Security audit of a web app

Run these 3 analyses in parallel:
- Analysis A: Check for SQL injection vulnerabilities
- Analysis B: Check for XSS vulnerabilities
- Analysis C: Check for authentication weaknesses

Then synthesize findings into a unified report.
```

**3. Conditional Chain Pattern**
```
Task: Process incoming support ticket

Step 1: Classify the ticket type
Step 2: IF urgent → escalate immediately
        IF technical → run diagnostics first
        IF billing → route to billing team
        IF general → generate standard response
```

---

## Exercises / تمارين

### Exercise 1: Build a Claude Code Prompt for Arabic Code Review
**التمرين الأول: بناء أمر Claude Code لمراجعة الكود العربي**

**Task:**
Create a Claude Code prompt that performs a comprehensive Arabic code review for an e-commerce API.

**Requirements:**
1. The prompt should check for:
   - SQL injection vulnerabilities
   - Input validation for Arabic text fields
   - Proper error handling with Arabic error messages
   - JWT authentication implementation
   - Rate limiting

2. The output should be formatted as a markdown report in Arabic with:
   - Summary section (ملخص)
   - Issues found (المشاكل المكتشفة) with severity levels
   - Recommendations (التوصيات)

3. Include example code to review

**Example Prompt Structure:**
```
Review this Arabic e-commerce API code for:
1. Security vulnerabilities
2. Arabic text handling
3. Error handling

[Insert code here]

Output format:
## ملخص
## المشاكل المكتشفة
## التوصيات
```

**Solution Example:**
The student should produce a prompt similar to:
```
You are an Arabic code reviewer for an e-commerce API.

Code to review:
[code]

Check for:
1. SQL injection in user input fields (especially Arabic text)
2. JWT validation on protected routes
3. Input sanitization for name_ar, address_ar fields
4. Rate limiting implementation
5. Error messages in Arabic

Output a markdown report in Arabic:
## ملخص المراجعة
[summary]
## المشاكل الحرجة (HIGH)
[issues]
## المشاكل المتوسطة (MEDIUM)
[issues]
## التوصيات
[recommendations]
```

---

### Exercise 2: Create an n8n Workflow Prompt for Lead Qualification
**التمرين الثاني: إنشاء أمر سير عمل n8n لتأهيل العملاء المحتملين**

**Task:**
Design an n8n workflow prompt that qualifies Arabic-speaking leads from a WhatsApp chatbot.

**Workflow Requirements:**
1. Receive incoming WhatsApp message
2. Extract: name, phone, message content
3. Classify lead quality (hot/warm/cold)
4. Route to appropriate sales team
5. Send confirmation message in Arabic

**The Prompt Should Include:**

```
You are an n8n AI node that qualifies leads from WhatsApp inquiries.

Input data:
- name: "{{$json.name}}"
- phone: "{{$json.phone}}"
- message: "{{$json.message}}"
- source: "{{$json.source}}"

Task: Classify the lead and route appropriately.

Classification rules:
- HOT: Explicit purchase intent + phone number provided
- WARM: Questions about products/services
- COLD: General questions or just greeting

Routing:
- HOT → immediate SMS to sales team + CRM entry
- WARM → email follow-up sequence
- COLD → add to nurture list

Output JSON:
{
  "lead_score": "hot|warm|cold",
  "confidence": 0.0-1.0,
  "recommended_action": "...",
  "arabic_response": "..."
}

Response in Arabic if customer wrote in Arabic.
```

**Deliverable:**
Write the complete n8n AI node prompt including:
- Input variables
- Classification logic
- Routing decisions
- Arabic response templates for each lead type

---

### Exercise 3: Design an MCP Integration Prompt
**التمرين الثالث: تصميم أمر تكامل MCP**

**Task:**
Create an MCP prompt that connects Claude Code to a PostgreSQL database for an Arabic customer management system.

**Scenario:**
You have a PostgreSQL database with:
- customers (id, name_ar, name_en, email, phone, city, created_at)
- orders (id, customer_id, total, status, created_at)
- products (id, name_ar, name_en, price, stock)

**The Prompt Should:**
```
You have MCP access to a PostgreSQL database: customer_db

Available tables:
- customers (id, name_ar, name_en, email, phone, city, created_at)
- orders (id, customer_id, total, status, created_at)
- products (id, name_ar, name_en, price, stock)

Task: Find the top 5 customers by total orders in the last 30 days who:
1. Are from Riyadh or Jeddah
2. Have spent more than 1000 SAR total
3. Have at least 3 orders

Output format:
| الاسم | المدينة | عدد الطلبات | إجمالي المبالغ |
|-------|---------|-------------|---------------|
| ... | ... | ... | ... |

Also identify:
- Average order value
- Most purchased product category
- Recommended VIP tier for each customer

Use Arabic for all output.
```

**Deliverable:**
Write the complete MCP prompt with:
- Database schema
- Query requirements
- Output format specifications
- Error handling instructions

---

## Quick Reference / مرجع سريع

### Claude Code Commands for Arabic Projects
```
# Start Arabic project session
claude "Initialize Arabic WhatsApp bot project"

# Resume with context
claude --resume

# Set Arabic locale
CLAUDE_LOCALE=ar claude
```

### n8n AI Node Template
```
You are an n8n AI node for [task description].

Input: {{$json.input_field}}
Context: {{$json.context}}

Task: [specific task]

Output format: JSON
Language: Respond in Arabic for Arabic input.

Rules:
1. [rule 1]
2. [rule 2]
3. If uncertain, escalate to human.
```

### MCP Database Query Template
```
You have MCP access to [database].

Schema:
- [table]: [columns]

Task: [query description]

Requirements:
- Output in Arabic
- Format as [markdown table/JSON/list]
- Handle errors gracefully

```

---

## Working Code Examples / أمثلة كود حقيقية

### English

This section contains complete, working code examples you can copy-paste and use immediately.

---

### 1. Complete n8n Workflow JSON

This is a working n8n workflow for an Arabic customer service bot. Import this directly into n8n:

```json
{
  "name": "Arabic Customer Service Bot",
  "nodes": [
    {
      "name": "WhatsApp Trigger",
      "type": "n8n-nodes-base.whatsAppTrigger",
      "position": [250, 300],
      "parameters": {
        "phoneNumberID": "{{$env.WHATSAPP_PHONE_ID}}"
      }
    },
    {
      "name": "Language Detection",
      "type": "n8n-nodes-base.function",
      "position": [450, 300],
      "parameters": {
        "functionCode": "const message = $input.item.json.message;\nconst isArabic = /[\\u0600-\\u06FF]/.test(message);\nreturn [{json: {lang: isArabic ? 'ar' : 'en', original: message}}];"
      }
    },
    {
      "name": "AI Classification",
      "type": "@n8n/n8n-nodes-langchain.chatOpenAI",
      "position": [650, 300],
      "parameters": {
        "resource": "chat",
        "operation": "complete",
        "model": "gpt-4",
        "messages": {
          "values": [
            {
              "role": "system",
              "content": "أنت مساعد دعم عملاء عربي. صنف الرسالة: SUPPORT أو SALES أو FEEDBACK أو OTHER"
            },
            {
              "role": "user", 
              "content": "={{$json.original}}"
            }
          ]
        },
        "options": {
          "temperature": 0.3
        }
      }
    },
    {
      "name": "Route by Intent",
      "type": "n8n-nodes-base.switch",
      "position": [850, 300],
      "parameters": {
        "dataType": "string",
        "value1": "={{$json.intent}}",
        "rules": {
          "rules": [
            {"value2": "SUPPORT", "operation": "equals", "output": 0},
            {"value2": "SALES", "operation": "equals", "output": 1},
            {"value2": "FEEDBACK", "operation": "equals", "output": 2}
          ]
        },
        "fallbackOutput": 3
      }
    }
  ],
  "connections": {
    "WhatsApp Trigger": {"main": [[{"node": "Language Detection", "type": "main"}]]},
    "Language Detection": {"main": [[{"node": "AI Classification", "type": "main"}]]},
    "AI Classification": {"main": [[{"node": "Route by Intent", "type": "main"}]]}
  }
}
```

**How to use:**
1. Copy this JSON
2. In n8n, click "Import from JSON"
3. Paste the workflow
4. Set up your WhatsApp credentials in n8n
5. Add your OpenAI API key

---

### 2. WhatsApp Bot with Baileys (Complete Working Code)

```javascript
// arabic-whatsapp-bot.js
const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const { default: fs } = require('fs');

// Arabic response templates
const RESPONSES = {
  greeting: {
    ar: 'مرحباً! كيف يمكنني مساعدتك اليوم؟',
    en: 'Hello! How can I help you today?'
  },
  support: {
    ar: 'سأساعدك في مشكلة الدعم الفني. ما هي التفاصيل؟',
    en: "I'll help you with technical support. What are the details?"
  },
  escalation: {
    ar: 'سأحولك لأحد المتخصصين. يرجى الانتظار.',
    en: 'I will connect you with a specialist. Please wait.'
  },
  unknown: {
    ar: 'عذراً، لم أفهم سؤالك. هل يمكنك إعادة صياغته؟',
    en: "Sorry, I didn't understand. Could you rephrase?"
  }
};

async function classifyMessage(message) {
  // Simple keyword-based classification
  const arabicKeywords = {
    support: ['مشكلة', 'خطأ', 'لا يعمل', 'عطل', 'مساعدة'],
    sales: ['سعر', 'طلب', 'شراء', 'منتج', 'كم']
  };
  
  const lower = message.toLowerCase();
  
  for (const [intent, keywords] of Object.entries(arabicKeywords)) {
    if (keywords.some(k => lower.includes(k))) {
      return intent;
    }
  }
  return 'unknown';
}

async function startBot() {
  const { state, saveState } = await useMultiFileAuthState('./auth_info');
  
  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true
  });

  sock.ev.on('creds.update', saveState);
  
  sock.ev.on('messages.upsert', async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;
    
    const from = msg.key.remoteJid;
    const messageText = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
    
    // Classify the message
    const intent = await classifyMessage(messageText);
    
    // Determine language
    const isArabic = /[\u0600-\u06FF]/.test(messageText);
    const lang = isArabic ? 'ar' : 'en';
    
    // Get response
    let response;
    if (intent === 'unknown') {
      response = RESPONSES.unknown[lang];
    } else if (intent === 'support') {
      response = RESPONSES.support[lang];
    } else {
      response = RESPONSES.greeting[lang];
    }
    
    // Send response
    await sock.sendMessage(from, { text: response });
    
    console.log(`[${new Date().toISOString()}] ${lang.toUpperCase()} ${intent}: ${messageText.substring(0, 50)}`);
  });
}

startBot().catch(console.error);
```

**To run:**
```bash
npm init -y
npm install @whiskeysockets/baileys
node arabic-whatsapp-bot.js
```

---

### 3. MCP Database Query (Real Example)

```typescript
// mcp-database-query.ts
// Example: Using MCP to query PostgreSQL for Arabic e-commerce

interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
  total_orders: number;
  total_value: number;
}

interface OrderItem {
  product_name: string;
  quantity: number;
  price: number;
}

async function getTopCustomers(days: number = 30): Promise<Customer[]> {
  // This prompt works with MCP PostgreSQL connection
  const prompt = `
لديك حق الوصول إلى قاعدة بيانات PostgreSQL عبر MCP.

قاعدة البيانات: production_ecommerce
الجداول:
- users (id, name, email, phone, created_at)
- orders (id, user_id, total, status, created_at)
- order_items (id, order_id, product_id, quantity)

المهمة: اعثر على أفضل 5 عملاء حسب قيمة الطلبات في آخر ${days} يوماً.
شمل: الاسم، البريد، الهاتف، عدد الطلبات، القيمة الإجمالية.
رتّب حسب القيمة الإجمالية تنازلياً.

أرجع النتائج كـ JSON.
`;

  // Execute via Claude Code with MCP:
  // /query The top 5 customers by order value in the last 30 days as JSON
  
  // Manual implementation for reference:
  const query = `
    SELECT 
      u.id,
      u.name,
      u.email, 
      u.phone,
      COUNT(o.id) as total_orders,
      COALESCE(SUM(o.total), 0) as total_value
    FROM users u
    JOIN orders o ON u.id = o.user_id
    WHERE o.created_at >= NOW() - INTERVAL '${days} days'
      AND o.status = 'completed'
    GROUP BY u.id, u.name, u.email, u.phone
    ORDER BY total_value DESC
    LIMIT 5;
  `;
  
  return []; // Return would come from MCP execution
}

// Example output when executed:
/*
[
  {
    "id": 42,
    "name": "أحمد محمد",
    "email": "ahmed@example.com",
    "phone": "+966501234567",
    "total_orders": 15,
    "total_value": 4250.00
  },
  {
    "id": 18,
    "name": "فاطمة علي",
    "email": "fatima@example.com", 
    "phone": "+966558765432",
    "total_orders": 12,
    "total_value": 3890.00
  }
]
*/
```

---

### 4. Claude Code Session Example (Real Prompts + Real Responses)

**Session Start:**
```
$ claude

Context: I'm building an Arabic e-commerce API with Node.js/Express.
Tech stack: Express.js, PostgreSQL with Prisma, JWT auth.
Current file: src/controllers/productController.ts

Task: Add a new endpoint to search products by Arabic name.
```

**Response from Claude Code:**
```typescript
// src/controllers/productController.ts

import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * البحث عن المنتجات بالاسم العربي
 * Search products by Arabic name
 */
export async function searchByArabicName(req: Request, res: Response) {
  const { query } = req.query;
  
  if (!query || typeof query !== 'string') {
    return res.status(400).json({
      error: 'الرجاء تقديم استعلام البحث',
      message: 'Please provide a search query'
    });
  }

  try {
    // Normalize Arabic text: remove diacritics
    const normalizedQuery = query
      .normalize('NFD')
      .replace(/[\u064B-\u0652]/g, '') // Remove tashkeel
      .toLowerCase();

    const products = await prisma.product.findMany({
      where: {
        OR: [
          {
            nameAr: {
              contains: normalizedQuery,
              mode: 'insensitive'
            }
          },
          {
            descriptionAr: {
              contains: normalizedQuery,
              mode: 'insensitive'
            }
          }
        ]
      },
      select: {
        id: true,
        nameAr: true,
        nameEn: true,
        price: true,
        image: true,
        category: true
      },
      take: 20
    });

    return res.json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    console.error('Search error:', error);
    return res.status(500).json({
      error: 'حدث خطأ في البحث',
      message: 'Search failed'
    });
  }
}
```

---

### العربية

هذا القسم يحتوي على أمثلة كود كاملة يمكنك نسخها واستخدامها فوراً.

---

## Quick Reference Templates

### Claude Code Starter Template
```
claude "[context] أعطيك كود [file path]
[task] أحتاجك لـ [action]
[constraints] مع [constraints]
[format] أرجع [format]"
```

### n8n AI Node Template
```
أنت [role] في سير عمل n8n.
المدخلات: {{$json.input}}
المهمة: [detailed task description]
الصيغة: [output format specification]
```

### Local LLM Template
```
System: [system prompt in Arabic]
User: [task in Arabic or English]
```

---

*Module 2 Complete — Next: Module 3: WhatsApp AI Agents*
*الوحدة الثانية مكتملة — التالي: الوحدة الثالثة: وكلاء واتساب الذكيين*
