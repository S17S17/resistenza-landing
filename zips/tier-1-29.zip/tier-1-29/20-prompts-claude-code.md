# 20 Arabic-Optimized Prompts for Claude Code
## 20 أمراً محسّناً للعربية لـ Claude Code

**Tier 1 — Starter**
Version 1.0 — April 2026

---

##如何使用 / How to Use

These prompts are designed for Claude Code CLI. Copy and paste into your Claude Code session for best results.

هذه الأوامر مصممة لـ Claude Code CLI. انسخ والصق في جلسة Claude Code الخاصة بك للحصول على أفضل النتائج.

---

## Prompts / الأوامر

### 1. Project Analyzer / محلل المشروع
```
أنا أعمل على مشروع位于 [directory path]. أريدك أن:

1. Explore the project structure using terminal commands
2. Read README.md if it exists
3. Identify the main technologies used
4. Find the entry points of the application
5. Give me a comprehensive summary in Arabic

Use: find, ls, cat commands to explore.
```

### 2. Bug Hunter / صائد الأخطاء
```
I have a bug in [file path]. The error is:
[error message here]

Please:
1. Read the file and find the problematic code
2. Trace back to find the root cause
3. Explain what's happening in Arabic
4. Fix the bug with proper error handling
5. Show me the corrected code
```

### 3. Feature Creator / منشئ الميزات
```
In the [folder path], create a new feature for [description]:

Requirements:
- [requirement 1]
- [requirement 2]
- [requirement 3]

Use [programming language]. Include:
- Proper types/interfaces
- Error handling
- Unit tests
- Documentation comments in Arabic
```

### 4. Code Reviewer / مراجع الكود
```
Review the code in [file/folder path] for:
1. Security vulnerabilities (SQL injection, XSS, etc.)
2. Performance issues
3. Code quality and best practices
4. RTL/l10n issues if applicable

For each issue found:
- Severity: High/Medium/Low
- Location: file:line
- Problem: explanation in Arabic
- Fix: recommendation
```

### 5. Test Writer / كاتب الاختبارات
```
Write comprehensive tests for [file path]:

Test cases:
- Happy path for all functions
- Edge cases (null, empty, extreme values)
- Error conditions
- [Any specific scenarios]

Use [testing framework]. Include:
- Unit tests
- Mock any external dependencies
- Coverage all public functions
```

### 6. Documentation Generator / مولد التوثيق
```
Generate documentation for [file/folder path]:

Include:
1. Overview of what this code does
2. All functions/classes with descriptions
3. Parameters and return types
4. Usage examples
5. Any known limitations

Write in Arabic with English for technical terms.
Format as markdown.
```

### 7. Refactoring Plan / خطة إعادة الهيكلة
```
Analyze [file/folder path] and create a refactoring plan:

1. Current problems (code smells, duplication, etc.)
2. Proposed structure
3. Migration steps
4. Risks and mitigations
5. Order of changes

Consider:
- Maintainability
- Performance impact
- Backward compatibility
```

### 8. API Endpoint Creator / منشئ نقاط API
```
Create a new API endpoint:

Framework: [Express/FastAPI/etc.]
Method: [GET/POST/PUT/DELETE]
Path: [endpoint path]

Request:
- [parameter 1]: type, required, description
- [parameter 2]: type, required, description

Response:
- Success (200): { structure }
- Error (400): { structure }
- Error (401): { structure }

Requirements:
- Input validation
- Error handling
- Authentication check if needed
- Rate limiting
```

### 9. Database Schema Designer / مصمم مخطط قاعدة البيانات
```
Design a database schema for [project description]:

Requirements:
- [entity 1] with [fields]
- [entity 2] with [fields]
- Relationship: [description]

Use [PostgreSQL/MySQL/MongoDB/etc.]:
1. Create the schema/migrations
2. Define indexes for query optimization
3. Add constraints for data integrity
4. Include seed data for testing

Write the complete schema with comments in Arabic.
```

### 10. Docker Config Generator / مولد إعدادات Docker
```
Create Docker configuration for [project type]:

1. Dockerfile with best practices
2. docker-compose.yml for local development
3. .dockerignore file
4. Any required environment variables

Requirements:
- Multi-stage build for smaller image
- Health checks
- Proper working directory
- Non-root user for security
```

### 11. CI/CD Pipeline / خط أنابيب CI/CD
```
Create a CI/CD pipeline for [project]:

Use: [GitHub Actions/GitLab CI/Jenkins/etc.]

Stages:
1. Build
2. Test (with coverage)
3. Lint
4. Deploy to [environment]

Requirements:
- Cache dependencies
- Run on PR and merge
- Notify on failure
- Deploy to [specific location]
```

### 12. Git Workflow Setup / إعداد سير عمل Git
```
Set up a professional Git workflow for this project:

1. Branch strategy (feature branches, etc.)
2. Commit message convention
3. Pull request template
4. Merge requirements (approvals, tests passing)
5. .gitignore file

Create the actual files and show me the commands to use.
```

### 13. Performance Optimizer / محسن الأداء
```
Optimize [file/path] for performance:

1. Profile and identify bottlenecks
2. Suggest specific optimizations
3. Implement caching if applicable
4. Optimize queries/database access
5. Add performance monitoring

Measure before and after. Report improvements in Arabic.
```

### 14. Security Hardening / تقوية الأمان
```
Harden the security of [project]:

1. Add authentication if missing
2. Implement authorization/permissions
3. Add input sanitization
4. Configure CORS properly
5. Add rate limiting
6. Set up security headers
7. Add logging for security events

Use industry best practices. Document each change.
```

### 15. Migration Script / سكريبت الترحيل
```
Create a migration script from [old system] to [new system]:

Data to migrate:
- [data type 1]
- [data type 2]

Requirements:
- Backup before migration
- Validate data integrity
- Rollback capability
- Progress tracking
- Error handling

Write the complete migration script with documentation.
```

### 16. CLI Tool Builder / بناء أداة CLI
```
Build a CLI tool for [purpose]:

Framework: [Commander/Clink/etc.]

Commands:
- [command 1]: description, options
- [command 2]: description, options

Features:
- Help text in Arabic
- Error handling
- Configuration file support
- Progress indicators

Create a complete, production-ready CLI tool.
```

### 17. Webhook Handler / معالج Webhook
```
Create a webhook handler for [service]:

Events to handle:
- [event 1]
- [event 2]

Requirements:
1. Verify webhook signature
2. Parse event payload
3. Process asynchronously
4. Handle retries on failure
5. Log all events

Create the complete handler with tests.
```

### 18. Monitoring Setup / إعداد المراقبة
```
Set up monitoring for [project]:

Metrics to track:
- Response times
- Error rates
- CPU/Memory usage
- [Custom metrics]

Use: [Prometheus/Grafana/DataDog/etc.]

1. Add instrumentation to code
2. Create dashboards
3. Set up alerts for:
   - Error rate > 5%
   - Response time > 2s
   - Any critical issue

Document all dashboards and alert configurations.
```

### 19. Payment Integration / دمج الدفع
```
Integrate payment processing for [provider]:

Provider: [Stripe/PayPal/etc.]

Features:
- Accept payments
- Handle webhooks
- Manage subscriptions if needed
- Refund handling

Requirements:
- PCI compliance considerations
- Proper error handling
- Idempotency for retries
- Test mode support

Create complete integration with tests.
```

### 20. Full Feature Implementation / تنفيذ ميزة كاملة
```
Implement a complete feature: [feature name]

For project at: [path]

Requirements:
- [requirement 1]
- [requirement 2]
- [requirement 3]

Steps:
1. Update/create database schema if needed
2. Create API endpoints
3. Implement business logic
4. Add frontend components if applicable
5. Write comprehensive tests
6. Update documentation

This is a production task. Follow all best practices.
```

---

## Usage Tips / نصائح الاستخدام

1. **Be Specific**: More specific prompts get better results
2. **Add Context**: Include file paths, error messages, requirements
3. **Iterate**: Start broad, then refine based on output
4. **Test**: Always review and test the generated code
5. **Save Good Prompts**: Keep prompts that work well for reuse

---

*20 Prompts for Claude Code — Tier 1 Starter*
