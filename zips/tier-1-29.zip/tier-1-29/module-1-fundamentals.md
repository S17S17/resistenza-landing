# Module 1: Prompt Engineering Fundamentals
## الوحدة الأولى: أساسيات هندسة الأوامر

**Arabic-English Bilingual Edition**
Version 1.0 — April 2026

---

## Table of Contents / جدول المحتويات

1. How LLMs Actually Work / كيف تعمل نماذج اللغة الكبيرة فعلاً
2. The Caveman Method / طريقة الرجل الكهفي
3. Arabic Token Optimization / تحسين التوكنات للعربية
4. Context Management / إدارة السياق
5. Arabic-Specific Considerations / اعتبارات خاصة بالعربية
6. Output Calibration / معايرة المخرجات

---

## Chapter 1: How LLMs Actually Work

### English

Large Language Models (LLMs) are, at their core, **next-token prediction machines**. They don't "understand" language the way humans do. They calculate the probability of what comes next given everything that came before.

Think of it like autocomplete on steroids. Given:
```
"The capital of France is"
```

The model calculates probabilities for every possible next token:
- "Paris" → 94.2%
- "Lyon" → 2.1%
- "the" → 1.3%
- ...

It picks the highest probability token (or samples from the distribution).

**What this means for you:**
- Models don't reason step-by-step by default — they predict tokens
- Chain-of-thought prompting works because it structures the prediction path
- Models are pattern matchers trained on vast text corpora
- "Understanding" is an emergent property of pattern matching at scale

### العربية

نماذج اللغة الكبيرة (LLMs) هي في جوهرها **آلات التنبؤ بالكلمة التالية**. لا "تفهم" اللغة بالطريقة التي يفهمها البشر. إنها تحسب احتمالية ما يأتي بعداً بناءً على كل ما جاء قبلاً.

فكر فيها كإكمال تلقائي بشكل مبالغ فيه. مع:
```
"عاصمة فرنسا هي"
```

النموذج يحسب الاحتمالات لكل كلمة ممكنة التالية:
- "باريس" → 94.2%
- "ليون" → 2.1%
- "مدينة" → 1.3%
- ...

يختار التوكن بأعلى احتمالية (أو يأخذ عينة من التوزيع).

**ما يعنيه هذا لك:**
- النماذج لا تستنتج خطوة بخطوة افتراضياً — إنها تتنبأ بالكلمات
- هندسة الأوامر بطريقة "سلسلة الأفكار" تعمل لأنها تنظم مسار التنبؤ
- النماذج هي مطابقات للأنماط مدربة على نصوص ضخمة
- "الفهم" هو خاصية ناشئة من مطابقة الأنماط على نطاق واسع

---

## Chapter 2: The Caveman Method

### English

The Caveman Method is a prompt engineering approach that strips away complexity and speaks to the model in its native "language of probability."

**The Core Insight:**
Models work best when instructions are:
1. **Direct** — Say exactly what you want
2. **Sequential** — One step at a time, in order
3. **Concrete** — Specific examples over abstract descriptions
4. **Grounded** — Reference available context

**The Caveman Prompt Structure:**

```
[Context] I have a [problem/file/situation]
[Task] I need you to [action]
[Constraints] While [specific limitations]
[Format] Output [exact format]
[Example] Like [concrete example]
```

**Why it works:**
- Direct commands reduce the "search space" for the model
- Sequential steps mirror how the model actually processes information
- Concrete examples anchor the model to known patterns
- Constraints prevent hallucination by narrowing focus

**Example — English:**
```
Context: I have a Python function that processes user login.
The function is in auth.py and takes (username, password).
Task: I need you to add rate limiting to prevent brute force attacks.
Constraints: Use only the standard library. Add a 5-minute lockout after 3 failed attempts.
Format: Return the complete updated function with comments.
Example: Like how Django's auth module handles failed login attempts.
```

**Example — العربية:**
```
السياق: لدي دالة بايثون تعالج تسجيل دخول المستخدم.
الدالة في auth.py وتأخذ (اسم المستخدم، كلمة المرور).
المهمة: أحتاجك لإضافة تحديد المعدل لمنع هجمات القوة الغاشمة.
القيود: استخدم المكتبة القياسية فقط. أضف قفل 5 دقائق بعد 3 محاولات فاشلة.
الصيغة: أرجع الدالة المحدّثة الكاملة مع التعليقات.
مثال: مثل طريقة وحدة auth في Django تعالج محاولات تسجيل الدخول الفاشلة.
```

---

## Chapter 3: Arabic Token Optimization

### English

**Critical fact: Arabic costs 2-4x more tokens than English.**

This is not a bug — it's a feature of how tokenizers work:

**Why Arabic is expensive:**
1. **Morphological complexity** — Arabic words can contain root+pattern+affixes in single tokens
2. **Diacritics** — Arabic diacritics (tashkeel) add characters but often get merged
3. **Character encoding** — Arabic uses right-to-left rendering, complicating tokenization
4. **Context window pressure** — Same prompt in Arabic vs English leaves you with 2-4x less context

**Token Optimization Techniques:**

**1. Remove Diacritics (تشكيل)**
```
❌ "عَلَيْكُمْ بِالتَّحَرُّي"
✅ "عليكم بالتحري"
```
Savings: ~30-40% tokens

**2. Use Modern Standard Arabic (MSA) over Dialectal**
```
❌ "كيفك اليوم يا حبيبي؟"
✅ "كيف حالك اليوم؟"
```

**3. Truncate Strategically**
When context is tight, prioritize:
- Instructions (highest value)
- Code/data (cannot be compressed)
- Examples (can be shortened)

**4. Use Latin Characters for Technical Terms**
```
❌ "استخدم دالة JSON.parse"
✅ "Use JSON.parse function"
```
For technical content, mixing Arabic context with English code is often optimal.

**5. Prefix with Language Instruction**
```
You are helping an Arabic-speaking developer.
Keep technical terms in English.
Respond in Arabic for explanations.
```

**Token Counter Reference:**
- Arabic word (3-4 letters): ~1 token
- English word (5 letters): ~1.3 tokens
- Arabic sentence: ~1.5-2x the English equivalent
- Code: Same in both languages

### العربية

**حقيقة مهمة: العربية تكلّف 2-4 أضعاف التوكنات أكثر من الإنجليزية.**

هذا ليس عيباً — إنه خاصية لكيفية عمل مقسمي النصوص (tokenizers):

**لماذا العربية مكلفة:**
1. **التعقيد الصرفي** — الكلمات العربية يمكن أن تحتوي جذر+وزن+لواحق في توكن واحد
2. **العلامات الصوتية** — تشكيلات العربية تضيف أحرفاً لكن غالباً ما تندمج
3. **ترميز الأحرف** — العربية تستخدم العرض من اليمين لليسار، مما يعقد التقسيم
4. **ضغط نافذة السياق** — نفس الأمر بالعربية مقابل الإنجليزية يتركك مع 2-4 أضعاف سياق أقل

**تقنيات تحسين التوكنات:**

**1. إزالة التشكيل**
```
❌ "عَلَيْكُمْ بِالتَّحَرُّي"
✅ "عليكم بالتحري"
```
توفير: ~30-40% توكنات

**2. استخدم الفصحى بدلاً من العامية**
```
❌ "كيفك اليوم يا حبيبي؟"
✅ "كيف حالك اليوم؟"
```

**3. اقطع استراتيجياً**
عندما يكون السياق ضيقاً، أعطِ الأولوية لـ:
- التعليمات (أعلى قيمة)
- الكود/البيانات (لا يمكن ضغطها)
- الأمثلة (يمكن اختصارها)

**4. استخدم الحروف اللاتينية للمصطلحات التقنية**
```
❌ "استخدم دالة JSON.parse"
✅ "Use JSON.parse function"
```
لل محتوى التقني، خلط السياق العربي مع الكود الإنجليزي غالباً هو الأمثل.

**5. ابدأ بتعليمات اللغة**
```
You are helping an Arabic-speaking developer.
Keep technical terms in English.
Respond in Arabic for explanations.
```

---

## Chapter 4: Context Management

### English

Context is your most precious resource when working with LLMs. Every prompt, every response, every file you share consumes context tokens.

**The Context Hierarchy (Most to Least Important):**

1. **Current task instruction** — What you need RIGHT NOW
2. **System prompt/constraints** — Rules the model must follow
3. **Relevant code/data** — The actual content to work with
4. **Conversation history** — What was discussed before
5. **Examples** — What good output looks like

**Context Management Strategies:**

**1. The Summary Pattern**
For long conversations, periodically summarize:
```
# Context summary (keep in mind):
- We're building a WhatsApp bot in Node.js
- User auth uses JWT tokens
- Database is PostgreSQL with Prisma ORM
- Current issue: messages not persisting after restart
```

**2. The Anchor Pattern**
Start new tasks by re-establishing context:
```
Starting new task. Project context:
- Repo: github.com/semah/arabic-whatsapp-bot
- Stack: Node.js, WhatsApp Web JS, PostgreSQL
- Current branch: feature/session-persistence

Task: Implement session persistence using Redis...
```

**3. The Chunk Pattern**
Break large tasks into context-sized pieces:
```
Part 1 of 3: Design the database schema
[Complete schema design]

Part 2 of 3: Implement the session manager
[Complete session manager]

Part 3 of 3: Add error handling and tests
[Complete error handling]
```

**4. Context Compression**
When near the limit, compress:
```
# Original (200 tokens)
"The user clicked the login button, which triggered the auth flow,
which called the /api/auth/login endpoint, which validated the credentials..."

# Compressed (40 tokens)
"User clicked login → /api/auth/login → validate credentials"
```

### العربية

السياق هو أثمن مورد لديك عند العمل مع نماذج اللغة الكبيرة. كل أمر، كل رد، كل ملف تشاركه يستهلك توكنات السياق.

**تسلسل السياق (من الأكثر للأقل أهمية):**

1. **تعليمات المهمة الحالية** — ما تحتاجه الآن
2. **نظام الأوامر/القيود** — القواعد التي يجب على النموذج اتباعها
3. **الكود/البيانات ذات الصلة** — المحتوى الفعلي للعمل عليه
4. **سجل المحادثة** — ما تم مناقشته من قبل
5. **الأمثلة** — كيف يبدو الناتج الجيد

**استراتيجيات إدارة السياق:**

**1. نمط الملخص**
للمحادثات الطويلة، لخص دورياً:
```
# ملخص السياق (ضعه في اعتبارك):
- نبني بوت واتساب بـ Node.js
- مصادقة المستخدم تستخدم رموز JWT
- قاعدة البيانات PostgreSQL مع Prisma ORM
- المشكلة الحالية: الرسائل لا تستمر بعد إعادة التشغيل
```

**2. نمط المرساة**
ابدأ المهام الجديدة بإعادة تأسيس السياق:
```
بدء مهمة جديدة. سياق المشروع:
- الريبو: github.com/semah/arabic-whatsapp-bot
- التقنية: Node.js، WhatsApp Web JS، PostgreSQL
- الفرع الحالي: feature/session-persistence

المهمة: تنفيذ استمرارية الجلسات باستخدام Redis...
```

**3. نمط القطع**
قسّم المهام الكبيرة إلى قطع بحجم السياق:
```
الجزء 1 من 3: تصميم مخطط قاعدة البيانات
[تصميم مخطط كامل]

الجزء 2 من 3: تنفيذ مدير الجلسات
[مدير جلسات كامل]

الجزء 3 من 3: إضافة معالجة الأخطاء والاختبارات
[معالجة أخطاء كاملة]
```

---

## Chapter 5: Arabic-Specific Considerations

### English

**RTL (Right-to-Left) Rendering:**
Arabic is read right-to-left. This affects how you should structure prompts:
- Put the most important information on the RIGHT side
- Use RTL alignment in your output expectations
- Remember: Arabic prompts in LLM interfaces often render LTR for the model

**Morphological Richness:**
Arabic has one of the most complex morphological systems:
- Root-based: كتب (k-t-b) can yield dozens of words
- Pattern-based: فعّل، تفعيل، مفعل، متفاعل
- This richness is both a strength and a challenge

**Diacritics (Tashkeel/التشكيل):**
- Fatha (َ), Kasra (ِ), Damma (ُ), Sukun (ْ)
- Most modern Arabic text omits diacritics
- Models handle undiacritized text better
- Add diacritics only when pronunciation matters

**Avoiding Common Mistakes:**
1. **Mixing Arabic and English without context**
```
❌ "اضغط على button"
✅ "اضغط على الزر" أو "Press the button"
```

2. **Ignoring dialect differences**
```
Egyptian: "إيه الأخبار؟"
MSA: "ما أخبارك؟"
Both are valid but choose one for consistency.
```

3. **Overusing Arabic in technical contexts**
For code, technical terms, and configs — English is often clearer:
```
❌ "أنشئ متغيراً اسمه counter"
✅ "Create a variable named counter"
```

### العربية

**العرض من اليمين لليسار (RTL):**
العربية تُقرأ من اليمين لليسار. هذا يؤثر على كيفية هيكلة الأوامر:
- ضع المعلومات الأهم على اليمين
- استخدم محاذاة RTL في توقعات المخرجات
- تذكر: أوامر العربية في واجهات النماذج غالباً تعرض LTR للنموذج

**الثروة الصرفية:**
العربية لديها أحد أكثر الأنظمة الصرفية تعقيداً:
- قاعدي: كتب (ك-ت-ب) يمكن أن ينتج عشرات الكلمات
- نمطي: فعّل، تفعيل، مفعل، متفاعل
- هذه الثروة هي قوة وتحدٍّ في نفس الوقت

**العلامات الصوتية (التشكيل):**
- فتحة (َ)، كسرة (ِ)، ضمة (ُ)، سكون (ْ)
- معظم النصوص العربية الحديثة تحذف التشكيل
- النماذج تتعامل مع النصوص بدون تشكيل أفضل
- أضف التشكيل فقط عندما تهم النطق

**تجنب الأخطاء الشائعة:**
1. **خلط العربية والإنجليزية بدون سياق**
```
❌ "اضغط على button"
✅ "اضغط على الزر" أو "Press the button"
```

2. **تجاهل الفروق اللهجية**
```
مصرية: "إيه الأخبار؟"
فصحى: "ما أخبارك؟"
كلاهما صحيح لكن اختر واحداً للثبات.
```

3. **الإفراط في استخدام العربية في السياقات التقنية**
للكود والمصطلحات التقنية والإعدادات — الإنجليزية غالباً أوضح:
```
❌ "أنشئ متغيراً اسمه counter"
✅ "Create a variable named counter"
```

---

## Chapter 6: Output Calibration

### English

Getting consistent output from LLMs requires calibration. Here's how:

**1. Specify Output Format Explicitly**
```
❌ "Explain how to authenticate users"
✅ "Explain how to authenticate users. Use this format:
1. [Step name]
   - Why: [reason]
   - Code: [code snippet]
   - Test: [how to verify]"
```

**2. Use Temperature Strategically**
- Temperature 0.0-0.2: Factual, coding, technical tasks
- Temperature 0.3-0.5: General reasoning, explanations
- Temperature 0.6-0.8: Creative tasks, brainstorming
- Temperature >0.8: Experimental, wild creativity

**3. Chain-of-Thought for Complex Tasks**
For complex reasoning:
```
Task: Should I refactor auth.py now or wait?
Think step by step:
1. What are the current pain points with auth.py?
2. What's the risk of refactoring vs not refactoring?
3. How long would a refactor take?
4. What's the deadline pressure?

Conclusion: [Based on above analysis]
```

**4. Self-Consistency Sampling**
For important decisions:
```
Solve this problem 3 different ways.
If all 3 give the same answer, I'm confident.
If they differ, show me the trade-offs.
```

**5. Constraining Hallucination**
```
When you're unsure, say "I'm not sure" instead of guessing.
For code: Only provide code you can explain.
For facts: Cite your source or admit uncertainty.
```

### العربية

الحصول على مخرجات متسقة من النماذج يتطلب المعايرة. إليك كيف:

**1. حدد صيغة المخرجات صراحة**
```
❌ "اشرح كيفية المصادقة على المستخدمين"
✅ "اشرح كيفية المصادقة على المستخدمين. استخدم هذا التنسيق:
1. [اسم الخطوة]
   - لماذا: [السبب]
   - الكود: [مقطع الكود]
   - الاختبار: [كيفية التحقق]"
```

**2. استخدم الحرارة (Temperature) بشكل استراتيجي**
- الحرارة 0.0-0.2: مهام واقعية، ترميز، تقنية
- الحرارة 0.3-0.5: استنتاج عام، شروحات
- الحرارة 0.6-0.8: مهام إبداعية، عصف ذهني
- الحرارة >0.8: تجريبية، إبداع حر

**3. سلسلة الأفكار للمهام المعقدة**
للاستنتاجات المعقدة:
```
المهمة: هل يجب أن أعيد هيكلة auth.py الآن أم أنتظر؟
فكر خطوة بخطوة:
1. ما هي نقاط الألم الحالية مع auth.py؟
2. ما هو خطر إعادة الهيكلة مقابل عدمها؟
3. كم ستستغرق إعادة الهيكلة؟
4. ما هو ضغط الموعد النهائي؟

الخلاصة: [بناءً على التحليل أعلاه]
```

**4. أخذ عينات الاتساق الذاتي**
للقرارات المهمة:
```
حل هذه المشكلة 3 طرق مختلفة.
إذا أعطت كل الطرق نفس الإجابة، أنا واثق.
إذا اختلفت، أرني المفاضلات.
```

**5. تقييد الهلوسة**
```
عندما تكون غير متأكد، قل "لست متأكداً" بدلاً من التخمين.
للكود: قدم فقط الكود الذي يمكنك شرحه.
ل للحقائق: استشهد بمصادرك أو اعترف بعدم اليقين.
```

---

## Exercises / تمارين

### Chapter 1: How LLMs Work
**تمرين 1.1: توقع التوكن**
```
Given this prompt: "عاصمة فرنسا هي"
What token is most likely to come next? Why?

Solution: "Paris" because it's statistically the most probable 
completion based on training data.
```

**تمرين 1.2: لماذا تفشل هذه التعليمات؟**
```
Prompt: "Be creative and also very precise"
Why might this give inconsistent results?

Solution: Conflicting constraints (creative vs precise) create 
a contradictory search space that confuses the model.
```

**تمرين 1.3: تحسين التوقعات**
```
How would you restructure this ambiguous request:
"Tell me about Python"

Better version:
"Explain Python basics for a beginner:
- What is Python?
- Main use cases
- Simple example"
```

---

### Chapter 2: The Caveman Method
**Exercise 2.1: Convert to Caveman Format**
```
Original: "Can you maybe help me if you have time to look at my code 
and potentially fix any bugs you find? Thanks!"

Convert to Caveman:
Context: I have a Python file called auth.py with a login function.
Task: Find and fix any bugs.
Constraints: Keep the function signature unchanged.
Format: Return the corrected function with comments.
Example: Like how the register() function handles errors in the same file.
```

**تمرين 2.2: حدد العناصر المفقودة**
```
Which elements are missing from this prompt?
"I need code for authentication"

Missing: Context (what kind of auth?), Constraints (language/framework?), 
Format (what should the output look like?), Example (what does good look like?)

Rewrite with all 5 elements.
```

**تمرين 2.3: طبّق الطريقة**
```
Write a Caveman prompt to:
- Add rate limiting to a Node.js Express API
- Use the express-rate-limit package
- Return complete, working middleware code
```

---

### Chapter 3: Arabic Token Optimization
**Exercise 3.1: Remove Diacritics**
```
Reduce this Arabic text by 30-40%:
"يُرِيدُ الطَّالِبُ أَنْ يَتَعَلَّمَ اللُّغَةَ العَرَبِيَّةَ"

Solution: "يريد الطالب ان يتعلم اللغة العربية"
Tokens saved: ~40%
```

**تمرين 3.2: صحّح الاستخدام المختلط**
```
Fix this mixed-language prompt:
"اضغط على button للدخول"

Better: Either fully Arabic OR use English structure:
"Press the login button" OR "اضغط على زر تسجيل الدخول"
```

**تمرين 3.3: حسّن للتكلفة**
```
This prompt costs ~180 tokens in Arabic.
Optimize it to under 100 tokens while keeping the meaning:

Original:
"أريدك أن تكتب لي دالة بايثون تقوم بحساب المتوسط الحسابي
لقائمة من الأرقام. يجب أن تتعامل الدالة مع القيم الفارغة
وأن ترجع رسالة مناسبة في حالة عدم وجود أرقام."

Optimized:
Python function: calculate average of number list.
Handle empty list → return error message.
Show example usage.
```

---

### Chapter 4: Context Management
**Exercise 4.1: Create a Context Summary**
```
After a 20-message conversation about building a WhatsApp bot,
create an effective context summary.

Solution:
# Context Summary
- Project: Arabic WhatsApp customer support bot
- Stack: Node.js, Baileys library, PostgreSQL
- Auth: JWT tokens
- Current: Implementing message classification
- Next step: Add Arabic NLP
```

**تمرين 4.2: طبّق نمط المرساة**
```
Start a new Claude Code session for an existing project.
Write the anchor prompt to re-establish context.

Solution:
Starting new task. Project context:
- Repo: github.com/semah/arabic-whatsapp-bot
- Stack: Node.js, Baileys, PostgreSQL, Prisma
- Branch: feature/arabic-nlp
- Last work: Message classification

Task: Add dialect detection to incoming messages.
```

**Exercise 4.3: Chunk a Large Task**
```
Break this task into 3 context-sized chunks:
"Build a complete e-commerce API with user auth, product catalog,
shopping cart, order processing, and payment integration."

Chunk 1: User auth (register, login, JWT, password reset)
Chunk 2: Product catalog (CRUD, search, categories, images)  
Chunk 3: Cart + Orders + Payment (cart ops, checkout, Stripe)
```

---

### Chapter 5: Arabic-Specific Considerations
**Exercise 5.1: Fix RTL Issues**
```
This form breaks on Arabic input. Fix it:
- Name field should accept Arabic names
- Date should use Hijri calendar
- Currency should show in Arabic numerals

Solution: Use RTL attributes, Hijri date library, Arabic-Indic numbers.
```

**تمرين 5.2: اختَر الفصحى أو العامية**
```
Choose the right register for each scenario:
1. Banking app interface
2. Chat with friends
3. Technical documentation

Solutions:
1. MSA (فصحى) - Formal banking requires standard language
2. Dialect (مصرية/خليجية) - Casual chat uses dialect
3. MSA with English technical terms - Documentation uses formal
```

**Exercise 5.3: Handle Mixed Content**
```
Write a prompt that works for this mixed Arabic/English content:
"اشحن الطلب #12345 إلى Dubai"

Solution:
System: Handle mixed Arabic/English input.
Extract: Order number (numeric), City (Arabic), Action (shipping).
Respond in Arabic.
```

---

### Chapter 6: Output Calibration
**Exercise 6.1: Specify Exact Format**
```
Rewrite to get consistent output:
Before: "Show me the users"
After: "List all users. Return as JSON array:
[{id, name, email, created_at}]
If no users, return: {error: 'No users found'}"
```

**تمرين 6.2: استخدم درجة الحرارة المناسبة**
```
What temperature for each task?
1. Writing poetry
2. Extracting facts from a document
3. Generating code

Solutions:
1. 0.7-0.9 (creative, varied outputs)
2. 0.0-0.2 (factual, consistent)
3. 0.0-0.2 (deterministic, exact)
```

**Exercise 6.3: Implement Chain-of-Thought**
```
Use CoT to debug:
"User gets 'undefined is not a function' when clicking submit"

Think step by step:
1. What causes this error?
2. Where in the code might this occur?
3. What could make the function undefined?
4. How to fix and prevent?

Solution: Add null check, verify function binding, add error boundary.
```

---

### Putting It Together / تجميع الكل

**Project: Build an Arabic Support Bot Prompt**

Using everything you've learned, write a complete prompt for an Arabic customer support bot:

Requirements:
- Use Caveman Method structure
- Optimize for Arabic tokens
- Manage context within 2000 tokens
- Handle both MSA and dialect
- Calibrate output for JSON format

Solution template provided in Module 3 (WhatsApp AI Agents).

---

## Quick Reference / مرجع سريع

### Caveman Prompt Template
```
[Context] لدي [وصف المشكلة/الملف/الوضع]
[Task] أحتاجك لـ [الفعل]
[Constraints] مع [القيود المحددة]
[Format] أرجع [الصيغة الدقيقة]
[Example] مثل [مثال ملموس]
```

### Token Optimization Checklist
- [ ] إزالة التشكيل من النص العربي
- [ ] استخدام الفصحى بدلاً من العامية
- [ ] استخدام الإنجليزية للمصطلحات التقنية
- [ ] ضغط السياق الطويل
- [ ] ترتيب حسب الأولوية: تعليمات > كود > أمثلة

### Temperature Guide
| Task | Temperature |
|------|------------|
| Code writing | 0.0-0.2 |
| Bug fixing | 0.0-0.1 |
| Explanation | 0.3-0.5 |
| Creative writing | 0.6-0.8 |
| Brainstorming | 0.7-0.9 |

---

*Module 1 Complete — Next: Module 2: AI Coding Agents*
*الوحدة الأولى مكتملة — التالي: الوحدة الثانية: وكلاء البرمجة الذكية*
