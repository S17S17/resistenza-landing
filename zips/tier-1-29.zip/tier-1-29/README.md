# Tier 1 — Starter ($29)
## المستوى الأول — المبتدئ ($29)

**Arabic Prompt Engineering Masterclass**

---

## What's Included / ماincluded

✅ **20 Arabic-Optimized Prompts for Claude Code**
Complete, copy-paste ready prompts for everyday coding tasks

✅ **Quick-Start Guide**
PDF-formatted guide to get you running in 10 minutes

✅ **1 Starter Template**
The Caveman Method template for writing better prompts

✅ **30-Day Support**
Email support for questions about the prompts

---

## File Structure / هيكل الملفات

```
tier-1-29/
├── README.md                    ← You are here
├── 20-prompts-claude-code.md   ← The 20 prompts
└── template-1-quickstart.md     ← Quick-start template
```

---

## How to Use / كيفية الاستخدام

### 1. Read the Quick-Start Guide
Start with `20-prompts-claude-code.md` to understand the prompt structure.

### 2. Pick a Prompt
Find the prompt that matches your task.

### 3. Copy and Customize
Copy the prompt, customize the [placeholders], paste into Claude Code.

### 4. Execute
Watch Claude Code execute your task.

---

## Quick-Start Steps / خطوات البداية السريعة

1. Open Claude Code in your terminal
2. Copy any prompt from `20-prompts-claude-code.md`
3. Paste into Claude Code
4. Adjust for your specific project
5. Hit enter and watch the magic

---

## Example Prompt / مثال

```
# Use Prompt #3: Feature Creator

"In the src/features/ folder, create a new feature for user preferences:
- Store theme preference (light/dark)
- Store preferred language (ar/en/fr)
- Use JSON file storage
- Include TypeScript types"

Paste into Claude Code → Get working code in seconds
```

---

## Getting Help / الحصول على المساعدة

Questions? Email within 30 days of purchase.

---

## Next Steps / الخطوات التالية

Like what you see? Upgrade to Tier 2 for:
- 50 prompts (vs 20)
- 4 complete modules
- 5 templates
- Lifetime updates

**Upgrade link in your Gumroad receipt.**

---

*Arabic Prompt Engineering Masterclass — Tier 1 Starter*
